#pragma once

#include "NumberGrid.h"
#include <mutex>

//typedef
typedef int t_task;

class ThreadedGrid : public NumberGrid {
public:
ThreadedGrid();
ThreadedGrid(const int& height, const int& width);
virtual ~ThreadedGrid();
virtual void calculateAllNumbers();
virtual void worker();

private:
std::vector<t_task> mTasks;
std::mutex mMutex;

};
