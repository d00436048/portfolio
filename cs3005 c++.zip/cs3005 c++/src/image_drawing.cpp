#include "image_menu.h"
#include "Image.h"
#include <iostream>
#include <cmath>


void diagonalQuadPattern( ActionData& action_data ){
    action_data.getInputImage1().setMaxColorValue(255);
    std::vector<int> topHalf;
    int h = getInteger(action_data,"Image height? ");
    action_data.getInputImage1().setHeight(h);
    action_data.getInputImage1().setWidth(getInteger(action_data,"Image width? "));



    //red-------------------------------------------------------
    for (int i = 0; i < (action_data.getInputImage1().getHeight()/2); i++ ){
        for (int j = 0; j < action_data.getInputImage1().getWidth(); j++ ){
            action_data.getInputImage1().setChannel(i, j, 0, 0);
        }
    }

    for (int i = (action_data.getInputImage1().getHeight()/2); i < action_data.getInputImage1().getHeight(); i++){
        for (int j = 0; j < action_data.getInputImage1().getWidth(); j++){
            action_data.getInputImage1().setChannel(i, j, 0, 255);
        }
    }

    //green------------------------------------------------------
    for (int i = 0; i < (action_data.getInputImage1().getHeight()); i++){
        for (int j = 0; j < action_data.getInputImage1().getWidth(); j++){
            int gc = ((2*i + 2*j)%256);
            action_data.getInputImage1().setChannel(i, j, 1, gc);
        }
    }

    //blue-------------------------------------------------------
    for (int i = 0; i < action_data.getInputImage1().getHeight(); i++){
        for(int j = 0; j < (action_data.getInputImage1().getWidth()/2); j++){
            action_data.getInputImage1().setChannel(i,j,2,0);
        }
    }

    for (int i = 0; i < action_data.getInputImage1().getHeight(); i++){
        for ( int j = ((action_data.getInputImage1().getWidth()/2)); j < action_data.getInputImage1().getWidth(); j++){
            action_data.getInputImage1().setChannel(i,j,2,255);
        }
    }
    //-----------------------------------------------------------
}

void stripedDiagonalPattern (ActionData& action_data){
    //p.setMaxColorValue(255);
    int height = getInteger(action_data, "Image height? ");
    int width = getInteger(action_data, "Image width? ");
    action_data.getInputImage1().setHeight(height);
    action_data.getInputImage1().setWidth(width);

    int temp = ((action_data.getInputImage1().getWidth() + action_data.getInputImage1().getHeight())/3);
    if (temp >= 255){
        action_data.getInputImage1().setMaxColorValue(255);
        //os << p.getMaxColorValue();
    }
    else{
        action_data.getInputImage1().setMaxColorValue(temp);
    }


    //set top half red to 0//
    for (int row = 0; row < (height/2); row++){
        for (int column = 0; column < width; column++){
            
            action_data.getInputImage1().setChannel(row, column, 0, 0);

        }
    }

    //sets red to max color value//
    for (int row = (height/2); row < height; row++){
        for (int column = 0; column < width; column++){
            if (row % 3 == 0){

                action_data.getInputImage1().setChannel(row,column,0,0);

            }
            if (row % 3 != 0){

                action_data.getInputImage1().setChannel(row,column,0,action_data.getInputImage1().getMaxColorValue());

            }
        }
    }

    for (int row = 0; row < height; row++){
        for (int column = 0; column < width; column++){

            int value = (row + width - column - 1)%(action_data.getInputImage1().getMaxColorValue()+1);
            action_data.getInputImage1().setChannel(row,column,1, value);

        }
    }

    for (int row = 0; row < height; row++){
        for (int column = 0; column < width; column++){
        if (column < row){

                action_data.getInputImage1().setChannel(row,column,2,0);


            }
        else{
                action_data.getInputImage1().setChannel(row,column,2,action_data.getInputImage1().getMaxColorValue());
            }
        }
    }

}

void simpleSquaresPattern(ActionData& action_data){
    int s;
    s = getInteger(action_data, "Image size? ");
    action_data.getInputImage1().setHeight(s);
    action_data.getInputImage1().setWidth(s);
    
    for (int row = 0; row < (s/2); row++){
        for (int column = 0; column < s; column++){
            
            action_data.getInputImage1().setChannel(row, column, 0, 127);

        }
    }

        for (int row = (s/2); row < s; row++){
        if (row % 3 == 0){
            for (int column = 0; column < s; column++){

                action_data.getInputImage1().setChannel(row,column,0,255);

            }
        }
    }

        for (int i = 0; i < action_data.getInputImage1().getHeight(); i++){
        for(int j = 0; j < (action_data.getInputImage1().getWidth()/2); j++){
            action_data.getInputImage1().setChannel(i,j,1,0);
        }
    }

    for (int i = 0; i < action_data.getInputImage1().getHeight(); i++){
        for ( int j = ((action_data.getInputImage1().getWidth()/2)); j < action_data.getInputImage1().getWidth(); j++){
            action_data.getInputImage1().setChannel(i,j,1,255);
        }
    }

    for (int i = 0; i < (action_data.getInputImage1().getHeight()); i++){
        for (int j = 0; j < action_data.getInputImage1().getWidth(); j++){
            int bc = 255;
            action_data.getInputImage1().setChannel(i, j, 2, bc);
        }
    }
}

void flagColumbiaPattern(ActionData& action_data){
    int s;
    s = getInteger(action_data, "Image height? ");
    int size;
    size = (3/2)*(s);
    action_data.getInputImage1().setHeight(s);
    action_data.getInputImage1().setWidth(size);
    
    for (int row = 0; row < (s/2); row++){
        for (int column = 0; column < size; column++){
            
                action_data.getInputImage1().setChannel(row, column, 0, 252);
                action_data.getInputImage1().setChannel(row, column, 1, 209);
                action_data.getInputImage1().setChannel(row, column, 2, 22);

        }
    }

        for (int row = (s/2); row < ((s/2)+(s/4)); row++){
            for (int column = 0; column < size; column++){

                action_data.getInputImage1().setChannel(row,column,0,0);
                action_data.getInputImage1().setChannel(row, column, 1, 56);
                action_data.getInputImage1().setChannel(row, column, 2, 147);

            }
        }
    

        for (int row = ((s/2)+(s/4)); row < s; row++){
            for (int column = 0; column < size; column++){

                action_data.getInputImage1().setChannel(row,column,0,206);
                action_data.getInputImage1().setChannel(row, column, 1, 17);
                action_data.getInputImage1().setChannel(row, column, 2, 38);

            
        }
    }

}

void setSize( ActionData& action_data ){
    int height = getInteger(action_data, "Height? ");
    int width = getInteger(action_data, "Width? ");
    action_data.getInputImage1().setHeight(height);
    action_data.getInputImage1().setWidth(width);
}

void setMaxColorValue( ActionData& action_data ){
    int mC = getInteger(action_data, "Max color value? ");
    action_data.getInputImage1().setMaxColorValue(mC);
}

void setChannel( ActionData& action_data ){
    int row = getInteger(action_data, "Row? ");
    int column = getInteger(action_data, "Column? ");
    int channel = getInteger(action_data, "Channel? ");
    int value = getInteger(action_data, "Value? ");
    action_data.getInputImage1().setChannel(row,column,channel,value);
}

void setPixel( ActionData& action_data ){
    //save variables to make code easiser to read
    //std::istream& is = action_data.getIS();
    //std::istream& os = action_data.getOS();
    int row = getInteger(action_data, "Row? ");
    int column = getInteger(action_data, "Column? ");
    int red = getInteger(action_data, "Red? ");
    int green = getInteger(action_data, "Green? ");
    int blue = getInteger(action_data, "Blue? ");
    action_data.getInputImage1().setPixel(row,column,red,green,blue);
}

void clearAll( ActionData& action_data ){
    for (int i = 0; i <= action_data.getInputImage1().getWidth(); i++){
        for (int j = 0; j <= action_data.getInputImage1().getHeight(); j++){
            int red = 0;
            int green = 0;
            int blue = 0;
            action_data.getInputImage1().setPixel(j,i,red,green,blue);
        }
    }
}

void drawCircle(ActionData& action_data){
    int CR = getInteger(action_data, "Center Row? ");
    int CC = getInteger(action_data, "Center Column? ");
    double radius =  getDouble(action_data, "Radius? ");
    int Red = getInteger(action_data, "Red? ");
    int Green = getInteger(action_data, "Green? ");
    int Blue = getInteger(action_data, "Blue? ");

    for (int currentRow = 0; currentRow < action_data.getInputImage1().getHeight(); currentRow++){
        for (int currentColumn = 0; currentColumn < action_data.getInputImage1().getWidth(); currentColumn++){
                //double deltaRow = (currentRow - CR);
                //double deltaColumn = (currentColumn - CC);
                
                //int distance = sqrt( (deltaRow^2) + (deltaColumn^2) )
                //double distance = std::sqrt(std::pow(deltaRow,2) + std::pow(deltaColumn,2));

                if (radius >= std::sqrt(std::pow(currentRow - CR,2) + std::pow(currentColumn - CC,2))){
                    action_data.getInputImage1().setPixel(currentRow, currentColumn, Red, Green, Blue);
                }
        }
    }
}

void drawBox(ActionData& action_data){
    int TR = getInteger(action_data, "Top Row? ");
    int LC = getInteger(action_data, "Left Column? ");
    int BR =  getInteger(action_data, "Bottom Row? ");
    int RC =  getInteger(action_data, "Right Column? ");
    int Red = getInteger(action_data, "Red? ");
    int Green = getInteger(action_data, "Green? ");
    int Blue = getInteger(action_data, "Blue? ");
    

    for (int currentRow = TR; currentRow <= BR; currentRow++){
        for (int currentColumn = LC; currentColumn <= RC; currentColumn++){

            action_data.getInputImage1().setPixel(currentRow, currentColumn, Red, Green, Blue);

            
        }
    }

}


//practice exam
void drawTestColorPattern(ActionData& action_data){
    int height = getInteger(action_data, "Height? ");
    int width = getInteger(action_data, "Width? ");
    int mcv = getInteger(action_data, "Max color value? ");
    action_data.getInputImage1().setHeight(height);
    action_data.getInputImage1().setWidth(width);
    action_data.getInputImage1().setMaxColorValue(mcv);

    int w = action_data.getInputImage1().getWidth();
    int h = action_data.getInputImage1().getHeight();

//top left
    for (int row = 0; row < h/2; row++){
        for (int col = 0; col < w/2; col++){
            action_data.getInputImage1().setPixel(row, col,mcv,0,0);
        }
    }


//top right
    for (int row = 0; row < h/2; row++){
        for (int col = w/2; col < w; col++)
            action_data.getInputImage1().setPixel(row, col,0,mcv,0);
        }
    
//bottom right
    for (int row = h/2; row < h; row++){
        for (int col = 0; col < w/2; col++)
            action_data.getInputImage1().setPixel(row, col,0,0,mcv);
        }
    
//bottom right
    for (int row = h/2; row < h; row++){
        for (int col = w/2; col < w; col++)
            action_data.getInputImage1().setPixel(row, col,mcv/2,mcv/2,mcv/2);
        }
    }


// //exam 2
// void drawSquare(ActionData& action_data){
//     int R = getInteger(action_data, "Row? ");
//     int C = getInteger(action_data, "Column? ");
//     double size =  getDouble(action_data, "Size? ");
//     int Red = getInteger(action_data, "Red? ");
//     int Green = getInteger(action_data, "Green? ");
//     int Blue = getInteger(action_data, "Blue? ");

//     for (int currentRow = (R - size/2); currentRow <= size; currentRow++){
//         for (int currentColumn = (C - size/2); currentColumn <= size; currentColumn++){

//             action_data.getInputImage1().setPixel(currentRow, currentColumn, Red, Green, Blue);

            
//         }
//     }

//}


void drawSquare(ActionData& action_data){
    int CR = getInteger(action_data, "Row? ");
    int CC = getInteger(action_data, "Column? ");
    double size =  getDouble(action_data, "Size? ");
    int Red = getInteger(action_data, "Red? ");
    int Green = getInteger(action_data, "Green? ");
    int Blue = getInteger(action_data, "Blue? ");

    for (int currentRow = 0; currentRow < action_data.getInputImage1().getHeight(); currentRow++){
        for (int currentColumn = 0; currentColumn < action_data.getInputImage1().getWidth(); currentColumn++){

                if (CR >= (size - size/2) && CC >= (size - size/2) && CR <= (size + size/2) && CC <= (size + size/2)){
                    action_data.getInputImage1().setPixel(currentRow, currentColumn, Red, Green, Blue);
                }
        }
    }
}

void configureGrid(ActionData& action_data){
    int height = getInteger(action_data, "Grid Height? ");
    int width = getInteger(action_data, "Grid Width? ");
    int mgv = getInteger(action_data, "Grid Max Value? ");
    action_data.getGrid().setGridSize(height,width);
    action_data.getGrid().setMaxNumber(mgv);
}

void setGrid(ActionData& action_data){
    int gr = getInteger(action_data, "Grid Row? ");
    int gc = getInteger(action_data, "Grid Column? ");  
    int gv = getInteger(action_data, "Grid Value? ");
    action_data.getGrid().setNumber(gr,gc,gv);
}

void applyGrid(ActionData& action_data){
    action_data.getGrid().setPPM(action_data.getOutputImage()); //check output image
}

//color table functions
void setColorTableSize(ActionData& action_data){
    int size = getInteger(action_data, "Size? ");
    action_data.getTable().setNumberOfColors(size);
}

void setColor(ActionData& action_data){
    int pos = getInteger(action_data, "Position? ");
    int red = getInteger(action_data, "Red? ");
    int green = getInteger(action_data, "Green? ");
    int blue = getInteger(action_data, "Blue? ");

    action_data.getTable()[pos].setRed(red);
    action_data.getTable()[pos].setGreen(green);
    action_data.getTable()[pos].setBlue(blue);
}
void setRandomColor(ActionData& action_data){
    int pos = getInteger(action_data, "Position? ");
    action_data.getTable().setRandomColor(255,pos);
}

void setColorGradient(ActionData& action_data){
    //look at action data if need syntax
    //make a color object using Color color1 = color(r,g,b)
    int pos1 = getInteger(action_data, "First position? ");
    int posRed = getInteger(action_data, "First red? ");
    int posGreen = getInteger(action_data, "First green? ");
    int posBlue = getInteger(action_data, "First blue? ");
    int pos2 = getInteger(action_data, "Second position? ");
    int posRed2 = getInteger(action_data, "Second red? ");
    int posGreen2 = getInteger(action_data, "Second green? ");
    int posBlue2 = getInteger(action_data, "Second blue? ");

    Color color1 = Color(posRed,posGreen,posBlue);
    Color color2 = Color(posRed2, posGreen2, posBlue2);

    action_data.getTable().insertGradient(color1, color2, pos1, pos2);
}

void applyGridColorTable(ActionData& action_data){
    action_data.getGrid().setPPM(action_data.getOutputImage(),action_data.getTable());
}

//complex fractal
void setFractalPlaneSize(ActionData& action_data){
    ComplexFractal *point = dynamic_cast<ComplexFractal *>(&action_data.getGrid());
    if (point != 0){
        double minx = getDouble(action_data, "Min X? ");
        double maxx = getDouble(action_data, "Max X? ");
        double miny = getDouble(action_data, "Min Y? ");
        double maxy = getDouble(action_data, "Max Y? ");
        point->setPlaneSize(minx, maxx, miny, maxy);
    }
    else{
        action_data.getOS() << "Not a ComplexFractal object. Can't set plane size." << std::endl;
    }
}

void calculateFractal(ActionData& action_data){
    action_data.getGrid().calculateAllNumbers();
}

//Julia set
void setJuliaParameters(ActionData& action_data){
    JuliaSet *point = dynamic_cast<JuliaSet *>(&action_data.getGrid());
    if (point != 0){
        double parametera = getDouble(action_data, "Parameter a? ");
        double parameterb = getDouble(action_data, "Parameter b? ");
        point->setParameters(parametera, parameterb);
    }
    else{
        action_data.getOS() << "Not a JuliaSet object. Can't set parameters." << std::endl;
    }
}

//practice exam paldea
void setInvertedColorGradient(ActionData& action_data){
    int pos = getInteger(action_data, "First position? ");
    int red = getInteger(action_data, "First red? ");
    int green = getInteger(action_data,"First green? ");
    int blue = getInteger(action_data, "First blue? ");
    int pos2 = getInteger(action_data, "Second position? ");
    Color color_one = Color(red,green,blue);

    action_data.getTable().insertInvertedGradient(color_one, pos, pos2);
}

void zoomPlane(ActionData& action_data){
    int zoom_factor = getInteger(action_data, "Zoom Factor? ");
    ComplexFractal *point = dynamic_cast<ComplexFractal *>(&action_data.getGrid());
    if (point != 0){
        point->zoomPlane(zoom_factor);
    }
    else{
        action_data.getOS() << "Not a ComplexFractal object. Can't zoom plane." << std::endl;
    }
}

//exam 3
void setEasyRandomColorGradient(ActionData& action_data){
    int pos1 = getInteger(action_data, "First position? ");
    int pos2 = getInteger(action_data, "Second position? ");
    action_data.getTable().insertEasyRandomGradient(pos1, pos2);
}

void panPlaneRight(ActionData& action_data){
    ComplexFractal *point = dynamic_cast<ComplexFractal *>(&action_data.getGrid());
    if (point != nullptr) {
        point->panPlaneRight(0.1);
    } else {
        action_data.getOS() << "Not a ComplexFractal object. Can't pan the plane right." << std::endl;
    }
}
void panPlaneLeft(ActionData& action_data){
    ComplexFractal *point = dynamic_cast<ComplexFractal *>(&action_data.getGrid());
    if (point != nullptr) {
        point->panPlaneLeft(0.1);
    } else {
        action_data.getOS() << "Not a ComplexFractal object. Can't pan the plane right." << std::endl;
    }
}

void panPlaneUp(ActionData& action_data){
    ComplexFractal *point = dynamic_cast<ComplexFractal *>(&action_data.getGrid());
    if (point != nullptr) {
        point->panPlaneUp(0.1);
    } else {
        action_data.getOS() << "Not a ComplexFractal object. Can't pan the plane right." << std::endl;
    }
}

void panPlaneDown(ActionData& action_data){
    ComplexFractal *point = dynamic_cast<ComplexFractal *>(&action_data.getGrid());
    if (point != nullptr) {
        point->panPlaneDown(0.1);
    } else {
        action_data.getOS() << "Not a ComplexFractal object. Can't pan the plane right." << std::endl;
    }
}

//threaded grid
void calculateFractalSingleThread(ActionData& action_data){
    action_data.getGrid().NumberGrid::calculateAllNumbers();
}
