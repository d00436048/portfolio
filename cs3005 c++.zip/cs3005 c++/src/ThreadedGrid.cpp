#include "ThreadedGrid.h"
#include <thread>

ThreadedGrid::ThreadedGrid() : NumberGrid(){
    //std::threads::hardware_concurrency
}

ThreadedGrid::ThreadedGrid(const int& height, const int& width) : NumberGrid(height, width){

}

ThreadedGrid::~ThreadedGrid(){

}

void ThreadedGrid::calculateAllNumbers(){
    //delegate tasks and add to mtasks
    //push each task in mtasks to a thread
    //use mutex appropriatly to multithread tasks


    //get number of virtual cores probably 16
    //may use try and catch
    int CPUs = std::thread::hardware_concurrency();

    std::vector<std::thread> current_threads; //vector of threads being used

    for (int row = 0; row < getHeight(); row ++){
        mTasks.push_back(row);
    }

    for (int active_CPUs = 0; active_CPUs < CPUs - 2; active_CPUs++){
        current_threads.push_back(std::thread(&ThreadedGrid::worker, this));
    }

    for (long unsigned int thread_join = 0; thread_join < current_threads.size(); thread_join++){
        current_threads[thread_join].join();
    }
}

void ThreadedGrid::worker(){
    while (mTasks.empty() == false){
        mMutex.lock();
        t_task Current_Task = mTasks.back(); //t_task = int type
        mTasks.pop_back();
        mMutex.unlock();
        for (int column = 0; column < getWidth(); column++){
            setNumber(Current_Task, column, calculateNumber(Current_Task, column));
        }
    }
}