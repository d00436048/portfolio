#include "ComplexFractal.h"
#include <cmath>

ComplexFractal::ComplexFractal() : ThreadedGrid(201, 301){
    mDx = 0.01;
    mDy = 0.01;
    mMin_x = -1.5;
    mMax_x = 1.5;
    mMin_y = -1;
    mMax_y = 1;
}

ComplexFractal::ComplexFractal( const int& height, const int& width, const double& min_x, const double& max_x, const double& min_y, const double& max_y ) : ThreadedGrid(height, width){
    mMin_x = min_x;
    mMax_x = max_x;
    mMin_y = min_y;
    mMax_y = max_y;
    mDx = ((max_x - min_x)/(width - 1));
    mDy = ((max_y - min_y)/(height - 1));
}

ComplexFractal::~ComplexFractal(){

}


double ComplexFractal::getMinX( ) const{
    return mMin_x;
}
double ComplexFractal::getMaxX( ) const{
    return mMax_x;
}
double ComplexFractal::getMinY( ) const{
    return mMin_y;
}

double ComplexFractal::getMaxY( ) const{
    return mMax_y;
}

void ComplexFractal::setGridSize( const int& height, const int& width ){
    int oh = getHeight();
    int ow = getWidth();
    if (height >= 2 && width >= 2){
        NumberGrid::setGridSize(height,width);
        if (oh != height || ow != width){
            double dx = calculateDeltaX();
            double dy= calculateDeltaY();
            setDeltas(dx,dy);
        }
    }
}
void ComplexFractal::setPlaneSize( const double& min_x, const double& max_x, const double& min_y, const double& max_y ){
    if (min_x >= -2 && min_x <= 2 && max_x >= -2 && max_x <= 2 && min_y >= -2 && min_y <= 2 && max_y >= -2 && max_y <= 2 ){
        if(min_x != max_x && min_y != max_y){
            if(min_x > max_x){
                mMin_x = max_x;
                mMax_x = min_x;
            }
            else{
                mMin_x = min_x;
                mMax_x = max_x;
            }
            if(min_y > max_y){
                mMin_y = max_y;
                mMax_y = min_y;
            }
            else{
                mMin_y = min_y;
                mMax_y = max_y;
            }
            double dx = calculateDeltaX();
            double dy= calculateDeltaY();
            setDeltas(dx,dy);
        }
    }
}

double ComplexFractal::getDeltaX( ) const{
    return mDx;
}

double ComplexFractal::getDeltaY( ) const{
    return mDy;
}

void ComplexFractal::setDeltas( const double& delta_x, const double& delta_y ){
    if (delta_x > 0 && delta_y > 0){
        mDx = delta_x;
        mDy = delta_y;
    }
}

double ComplexFractal::calculateDeltaY( ) const{
    double delta_y = (mMax_y - mMin_y) / (ThreadedGrid::getHeight() - 1);
    return delta_y;
}

double ComplexFractal::calculateDeltaX( ) const{
    double delta_x = (mMax_x - mMin_x) / (ThreadedGrid::getWidth() - 1);
    return delta_x;
}

double ComplexFractal::calculatePlaneXFromPixelColumn( const int& column ) const{
    if (column < 0 || column >= ThreadedGrid::getWidth()){
        return 0;
    }
    else{
        double x = (mMin_x + column * mDx);
        return x;
    }
}

double ComplexFractal::calculatePlaneYFromPixelRow( const int& row ) const{
    if (row < 0 || row >= ThreadedGrid::getHeight()){
        return 0;
    }
    else{
        double y = (mMax_y - row * mDy);
        return y;
    }
}

void ComplexFractal::calculatePlaneCoordinatesFromPixelCoordinates( const int& row, const int& column, double& x, double& y ) const{
    if (row < 0 || row >= ThreadedGrid::getHeight() || column < 0 || column >= ThreadedGrid::getWidth()){
        x = 0;
        y = 0;
    }
    else{
        x = calculatePlaneXFromPixelColumn(column);
        y = calculatePlaneYFromPixelRow(row);
    }
}

int ComplexFractal::calculateNumber( const int& row, const int& column ) const{
    if (row < 0 || row >= ThreadedGrid::getHeight() || column < 0 || column >= ThreadedGrid::getWidth()){
        return -1;
    }
    else{
        double x = calculatePlaneXFromPixelColumn(column);
        double y = calculatePlaneYFromPixelRow(row);

        return std::abs(getMaxNumber() * std::sin(10*x) * std::cos(10*y));
    }
}

//practice exam paldea
void ComplexFractal::zoomPlane(const double& zoom_factor){
    double difx = mMax_x - mMin_x;
    double dify = mMax_y - mMin_y;

    double desired_x = difx*zoom_factor;
    double desired_y = dify*zoom_factor;

    double xchange = (difx - desired_x)/2;
    double ychange = (dify - desired_y)/2;

    double new_minx = xchange+mMin_x;
    double new_miny = ychange+mMin_y;

    if (new_minx < -2.0){
        new_minx = -2.0;
    }
    
    if (new_miny < -2.0){
        new_miny = -2.0;
    }

    double new_maxx = mMax_x-xchange;
    double new_maxy = mMax_y-ychange;


    if (new_maxx > 2.0){
        new_maxx = 2.0;
    }
    if (new_maxy > 2.0){
        new_maxy = 2.0;
    }

    setPlaneSize(new_minx, new_maxx, new_miny, new_maxy);


}

//exam 3
void ComplexFractal::panPlaneRight(const double& pan_factor){
    double x_size = mMin_x - mMax_x;
    double pan_size = x_size*pan_factor;
    double new_min_x = pan_size+mMin_x;
    double new_max_x = pan_size+mMax_x;

    if (new_min_x <= 2.0 && new_max_x <= 2.0){
        setPlaneSize(new_min_x, new_max_x, mMin_y, mMax_y);
    }
}

void ComplexFractal::panPlaneLeft(const double& pan_factor){
    double x_size = mMin_x - mMax_x;
    double pan_size = x_size*pan_factor;
    double new_min_x = mMin_x-pan_size;
    double new_max_x = mMax_x-pan_size;

    if (new_min_x >= -2.0 && new_max_x >= -2.0){
        setPlaneSize(new_min_x, new_max_x, mMin_y, mMax_y);
    }
}

void ComplexFractal::panPlaneUp(const double& pan_factor){
    double y_size = mMin_y - mMax_y;
    double pan_size = y_size*pan_factor;
    double new_min_y = pan_size+mMin_y;
    double new_max_y = pan_size+mMax_y;

    if (new_min_y <= 2.0 && new_max_y <= 2.0){
        setPlaneSize(mMin_x, mMax_x, new_min_y, new_max_y);
    }
}

void ComplexFractal::panPlaneDown(const double& pan_factor){
    double y_size = mMin_y - mMax_y;
    double pan_size = y_size*pan_factor;
    double new_min_y = mMin_y-pan_size;
    double new_max_y = mMax_y-pan_size;

    if (new_min_y >= -2.0 && new_max_y >= -2.0){
        setPlaneSize(mMin_x, mMax_x, new_min_y, new_max_y);
    }
}
