#include "ColorTable.h"
#include <cmath>
#include <iostream>

Color::Color(){
    setRed(0);
    setGreen(0);
    setBlue(0);
}

Color::Color( const int& red, const int& green, const int& blue ){
    mRed = red;
    mGreen = green;
    mBlue = blue;
}

int Color::getRed( ) const{
    return mRed;
}

int Color::getGreen( ) const{
    return mGreen;
}

int Color::getBlue( ) const{
    return mBlue;
}

int Color::getChannel( const int& channel ) const{
    if (channel == 0){
        return mRed;
    }
    else if (channel == 1){
        return mGreen;
    }
    else if (channel == 2){
        return mBlue;
    }
    else{
        return -1;
    }
}

void Color::setRed( const int& value ){
    if (value >= 0){
        mRed = value;
    }
}

void Color::setGreen( const int& value ){
    if (value >= 0){
        mGreen = value;
    }
}

void Color::setBlue( const int& value ){
    if (value >= 0){
        mBlue = value;
    }
}

void Color::setChannel( const int& channel, const int& value ){
    if (value >= 0){
        if (channel == 0){
            mRed = value;
        }
        else if (channel == 1){
            mGreen = value;
        }
        else if (channel == 2){
          mBlue = value;
        }
    }
}

void Color::invert( const int& max_color_value ){
    if (max_color_value < mRed || max_color_value < mGreen || max_color_value < mBlue){
        return;
    }
    else{
    mRed = max_color_value - mRed;
    mGreen = max_color_value - mGreen;
    mBlue = max_color_value - mBlue;
    }
}

bool Color::operator==( const Color& rhs ) const{
    if (mRed == rhs.mRed && mGreen == rhs.mGreen && mBlue == rhs.mBlue){
        return true;
    }
    else{
        return false;
    }
}

// color class support function //if not work add back color parameter
std::ostream& operator<<( std::ostream& os, const Color& color){
    os << color.getRed() << ":" << color.getGreen() << ":" << color.getBlue();
    return os;
}


//ColorTable class

ColorTable::ColorTable( const int& num_color ){
    mColors = std::vector<Color>(num_color); //is same as setNumber Of colors?----------
}

int ColorTable::getNumberOfColors( ) const{
    return mColors.size();
}

void ColorTable::setNumberOfColors( const int& num_color ){
    mColors.resize(num_color);
}

static Color orc1(-1,-1,-1);
static Color orc2(-1,-1,-1);
//------------------------------------------------------------------------
const Color& ColorTable::operator[]( const int& i ) const{
    if (i < 0 || i >= getNumberOfColors()){
        orc1 = orc2;
        return orc1;
    }
    else{
        return mColors[i];
    }
}
//------------------------------------------------------------------------


Color& ColorTable::operator[]( const int& i ){
    
    if (i < 0 || i >= getNumberOfColors()){
        orc1 = orc2;
        return orc1;
    }
    else{
        return mColors[i];
    }
}
//------------------------------------------------------------------------
void ColorTable::setRandomColor( const int& max_color_value, const int& position ){
    if (position >= 0 && position < getNumberOfColors() && max_color_value >= 0){
        if (max_color_value == 0){
            mColors[position].setRed(0);
            mColors[position].setGreen(0);
            mColors[position].setBlue(0);
        }
        else{
            int randR = std::rand() % max_color_value;
            int randG = std::rand() % max_color_value;
            int randB = std::rand() % max_color_value;
            mColors[position].setRed(randR);
            mColors[position].setGreen(randG);
            mColors[position].setBlue(randB);
        }
    }
}

double ColorTable::gradientSlope(const double y1, const double y2, const double x1, const double x2) const{
    double slopeY = y2-y1;
    double slopeX = x2-x1;
    double slope =slopeY/slopeX;

    return slope;
}

double ColorTable::gradientValue(const double y1, const double x1, const double slope, const double x) const{
    double y = y1 + slope * (x - x1);
    return y;
}

void ColorTable::insertGradient( const Color& color1, const Color& color2, const int& position1, const int& position2 ){
    if (position1 >= 0 && position1 < getNumberOfColors() && position2 < getNumberOfColors() && position1 < position2)   {
        double slopeR = gradientSlope(color1.getRed(), color2.getRed(), position1, position2);
        double slopeG = gradientSlope(color1.getGreen(), color2.getGreen(), position1, position2);
        double slopeB = gradientSlope(color1.getBlue(), color2.getBlue(), position1, position2);
        
        for (int i = position1; i <= position2; i++){
            double R = gradientValue(color1.getRed(), position1, slopeR, i);
            double G = gradientValue(color1.getGreen(), position1, slopeG, i);
            double B = gradientValue(color1.getBlue(), position1, slopeB, i);

            mColors[i] = Color(R, G, B);
            
        }
    }
}

int ColorTable::getMaxChannelValue() const{
    int maxChannelValue = 0; // Initialize to a minimum valid value (assuming all channel values are non-negative).

    int numColors = mColors.size(); // Use the size() method to get the number of colors in the vector.

    for (int i = 0; i < numColors; i++) {
        const Color& currentColor = mColors[i]; // Access the Color object directly from the vector.

        int red = currentColor.getRed();
        int green = currentColor.getGreen();
        int blue = currentColor.getBlue();

        // Check if any of the channel values (red, green, or blue) is greater than the current max.
        if (red > maxChannelValue) {
            maxChannelValue = red;
        }
        if (green > maxChannelValue) {
            maxChannelValue = green;
        }
        if (blue > maxChannelValue) {
            maxChannelValue = blue;
        }
    }

    return maxChannelValue;
}

//helper function not part o finsturctions
//Color& ColorTable::getlastColor() const{
//    return mColors.back();
//}

//practice exam paldea
void ColorTable::insertInvertedGradient(const Color& color1, const int& position1, const int& position2){
    int red = color1.getRed();
    int green = color1.getGreen();
    int blue = color1.getBlue();

    int invert_red = (255 - red);
    int invert_green = (255 - green);
    int invert_blue = (255- blue);

    Color color2 = Color(invert_red, invert_green, invert_blue);

    insertGradient(color1, color2, position1, position2);
}

//exam3
void ColorTable::insertEasyRandomGradient(const int& position1, const int& position2){
    if (position1 >= 0 && position1 < getNumberOfColors() && position2 >= 0 && position2 < getNumberOfColors() && position1 < position2){
        setRandomColor(255, position1);
        setRandomColor(255, position2);
        insertGradient(mColors[position1], mColors[position2], position1, position2);
    }
}