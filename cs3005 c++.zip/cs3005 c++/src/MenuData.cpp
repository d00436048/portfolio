#include "MenuData.h"

MenuData::MenuData(){

}

void MenuData::addAction(const std::string& name, ActionFunctionType func, const std::string& description){
    Cnames.push_back(name);
    cnafMap[name] = func;
    cncdMap[name] = description;
}

const std::vector<std::string>& MenuData::getNames() const{
    return Cnames;
}

ActionFunctionType MenuData::getFunction(const std::string& name){
    if (cnafMap.count(name)){
        return cnafMap[name];
    }
    return 0;
}

const std::string& MenuData::getDescription(const std::string& name){
    if (cncdMap.count(name)){
        return cncdMap[name];
    }
    static std::string emptystr = "";
    return emptystr;
 }