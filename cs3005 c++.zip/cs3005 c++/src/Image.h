#ifndef _IMAGE_
#define _IMAGE_

#include <iostream>
#include <vector>

class Image{ 
public:
    Image();

    Image(const int& height, const int& width);

    int getHeight() const;
    int getWidth() const;

    bool indexValid( const int& row, const int& column, const int& channel ) const;
    
    int index( const int& row, const int& column, const int& channel ) const;
    int getChannel( const int& row, const int& column, const int& channel ) const;
    
    void setHeight( const int& height );
    void setWidth( const int& width );
    void setChannel( const int& row, const int& column, const int& channel, const int& value );


    //squares
    
    
    //

private:
    int mX;
    int mY;
    std::vector<int> mPixels;



};

#endif /* _IMAGE_ */