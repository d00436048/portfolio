#include "MandelbrotSet.h"
#include <cmath>

MandelbrotSet::MandelbrotSet() : ComplexFractal() {

}

MandelbrotSet::MandelbrotSet( const int& height, const int& width, const double& min_x, const double& max_x, const double& min_y, const double& max_y ) 
: ComplexFractal(height, width, min_x, max_x, min_y, max_y){

}

MandelbrotSet::~MandelbrotSet( ){}

void MandelbrotSet::calculateNextPoint( const double x0, const double y0, const double& a, const double& b, double& x1, double &y1 ) const{
    x1 = x0*x0 - y0*y0 + a;
    y1 = 2*x0*y0 + b;
}

int MandelbrotSet::calculatePlaneEscapeCount( const double& a, const double& b ) const{
    double x1;
    double y1;
    double x2 = 0; //messed up?
    double y2 = 0; //messed up?
    double distance = sqrt(x2*x2 + y2*y2);
    int iterations = 0;
    int max_iterations = getMaxNumber();

    for (iterations = -1; iterations < max_iterations; iterations++){
        calculateNextPoint(x2,y2,a,b,x1,y1);
        distance = sqrt(x2*x2 + y2*y2);
        x2 = x1;
        y2 = y1;
        if (distance > 2){
            return iterations;
        }

    }
    return iterations;
}

int MandelbrotSet::calculateNumber( const int& row, const int& column ) const{
    double x1;
    double y1;
    //double distance;
    if (row < 0 || row >= getHeight() || column < 0 || column >= getWidth()){
        return -1;
    }
    else{
        ComplexFractal::calculatePlaneCoordinatesFromPixelCoordinates(row, column, x1, y1);
        return calculatePlaneEscapeCount(x1, y1);
    }
}
