#include <iostream>
#include "image_menu.h"

int main(){
    return buck(std::cin, std::cout);
}