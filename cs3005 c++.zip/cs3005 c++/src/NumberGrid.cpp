#include "NumberGrid.h"
    
NumberGrid::NumberGrid(){
    setGridSize(300,400);
    setMaxNumber(255);
    for (int width = 0; width < getWidth(); width++){
        for (int height = 0; height < getHeight(); height++){
            setNumber(height,width,0);
        }
    }
}

NumberGrid::NumberGrid( const int& height, const int& width ){
    setGridSize(height,width);
    setMaxNumber(255);
    for (int i = 0; i < getWidth(); i++){
        for (int j = 0; j < getHeight(); j++){
            setNumber(j,i,0);
        }
    }
}

NumberGrid::~NumberGrid(){

}

int NumberGrid::getHeight() const{
    return mGH;
}

int NumberGrid::getWidth() const{
    return mGW;
}

int NumberGrid::getMaxNumber() const{
    return mMax;
}

void NumberGrid::setGridSize( const int& height, const int& width ){
    if (height >= 2 && width >= 2){
            mGH = height;
            mGW = width;
            int vectVal = (getWidth()*getHeight());
            mGNum.resize(vectVal);
    }
}

void NumberGrid::setMaxNumber( const int& number ){
    if  (number >= 0){
        mMax = number; //maybe loop through and make values larger than mMax null
    }
}

const std::vector< int >& NumberGrid::getNumbers( ) const{
    return mGNum;
}

int NumberGrid::index( const int& row, const int& column ) const{
    int number = row * getWidth() + column;
    return number;
}

bool NumberGrid::indexValid( const int& row, const int& column ) const{
    if (row >= 0 && row < getHeight() && column >= 0 && column < getWidth()){
        return true;
    }
    else{
        return false;
    }
}

bool NumberGrid::numberValid( const int& number ) const{
    if (number >= 0 && number <= getMaxNumber()){
        return true;
    }
    else{
        return false;
    }
}

int NumberGrid::getNumber( const int& row, const int& column ) const{
    if (indexValid(row,column)){
        int num = index(row,column);
        return mGNum[num];
    }
    else{
        return -1;
    }
}

void NumberGrid::setNumber( const int& row, const int& column, const int& number ){
    if (numberValid(number) && indexValid(row, column)){
        mGNum[index(row, column)] = number;
    }
}

void NumberGrid::setPPM( PPM& ppm ) const{
    ppm.setWidth(getWidth());
    ppm.setHeight(getHeight());
    ppm.setMaxColorValue(63);

    for (int col = 0; col <= getWidth(); col++){
        for (int row = 0; row <= getHeight(); row++){\
            int number = getNumber(row,col);

            if (number == 0){
                ppm.setPixel(row, col,0,0,0);
            }
            else if (number == getMaxNumber()){
                ppm.setPixel(row, col,63,31,31);
            }
            else if (number % 8 == 0){
                ppm.setPixel(row, col,63,63,63);
            }
            else if (number % 8 == 1){
                ppm.setPixel(row, col,63,31,31);
            }
            else if (number % 8 == 2){
                ppm.setPixel(row, col,63,63,31);
            }
            else if (number % 8 == 3){
                ppm.setPixel(row, col,31,63,31);
            }
            else if (number % 8 == 4){
                ppm.setPixel(row, col,0,0,0);
            }
            else if (number % 8 == 5){
                ppm.setPixel(row, col,31,63,63);
            }
            else if (number % 8 == 6){
                ppm.setPixel(row, col,31,31,63);
            }
            else if (number % 8 == 7){
                ppm.setPixel(row, col,63,31,63);
            }
        }
    }
}

//color table
void NumberGrid::setPPM( PPM& ppm, const ColorTable& colors ) const{


    if (colors.getNumberOfColors() >= 2){
        int other_index_value;
        int ind;
        
        ppm.setHeight(getHeight()); //
        ppm.setWidth(getWidth()); //
        ppm.setMaxColorValue(colors.getMaxChannelValue()); //

        for (int j = 0;  j < getHeight(); j++){
            for (int i = 0; i < getWidth(); i++){
                int value = getNumber(j,i);

                if (value == getMaxNumber()){
                    ind = colors.getNumberOfColors() -1;
                }
                else{
                    other_index_value = (value % colors.getNumberOfColors());
                    ind = other_index_value;
                }

                    ppm.setPixel(j,i,colors[ind].getRed(),colors[ind].getGreen(),colors[ind].getBlue());
            }
        }
    }
    else{
        return;
    }    
}

//complex fractal
void NumberGrid::calculateAllNumbers(){
    for (int row = 0; row < getHeight(); row++){
        for(int col = 0; col < getWidth(); col++){
            setNumber(row, col, calculateNumber(row,col));
        }
    }
}