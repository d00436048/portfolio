#include <iostream>
#include "image_menu.h"

//comment


int main(){
    return assignment3(std::cin, std::cout);
}