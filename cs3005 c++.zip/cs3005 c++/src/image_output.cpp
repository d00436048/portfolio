#include <iostream>
#include <fstream>
#include <string>
#include "PPM.h"
#include "image_menu.h"

void drawAsciiImage( ActionData& action_data){
    (void) action_data.getIS();

    for (int row = 0; row < action_data.getOutputImage().getHeight(); row++ ){
        for (int column = 0; column < action_data.getOutputImage().getWidth(); column++){
            int red = action_data.getOutputImage().getChannel(row, column,0);
            int green = action_data.getOutputImage().getChannel(row,column,1);
            int blue = action_data.getOutputImage().getChannel(row,column, 2);

            double strength = ((red + green + blue)/765.0);
            std::string key;


            if (strength >= 1.0){
                key = "@";
            }
            else if (strength >= 0.9){
                key = "#";
            }
            else if (strength >= 0.8){
                key = "%";
            }
            else if (strength >= 0.7){
                key = "*";
            }
            else if (strength >= 0.6){
                key = "|";
            }
            else if (strength >= 0.5){
                key = "+";
            }
            else if (strength >= 0.4){
                key = ";";
            }
            else if (strength >= 0.3){
                key = "~";
            }
            else if (strength >= 0.2){
                key = "-";
            }
            else if (strength >= 0.1){
                key = ".";
            }
            else if (strength >= 0.0){
                key = " ";
            }


            action_data.getOS() << key;

        }
            action_data.getOS() << std::endl;

    }

}


void writeUserImage(ActionData& action_data){
   
    std::string filename = getString(action_data, "Output filename? ");

    std::ofstream file_out(filename, std::ios::binary);

    action_data.getOutputImage().writeStream(file_out);

    file_out.close();

     }

//ppm menu -------------------------------------------------------------------------------------------------------
void copyImage(ActionData& action_data){
    action_data.getOutputImage() = action_data.getInputImage1();
}

void readUserImage1( ActionData& action_data ){
    std::string filename = getString(action_data, "Input filename? ");
    std::ifstream file_in(filename, std::ios::binary);
    action_data.getInputImage1().readStream(file_in);
    if (file_in.fail()){
        action_data.getOS() << ("'" + filename + "' could not be opened.");
    }
    file_in.close();
}

void readUserImage2( ActionData& action_data ){
    std::string filename = getString(action_data, "Input filename? ");
    std::ifstream file_in(filename, std::ios::binary);
    action_data.getInputImage2().readStream(file_in);
    if (file_in.fail()){
        action_data.getOS() << ("'" + filename + "' could not be opened.");
    }
    file_in.close();
}