#include <iostream>
#include "image_menu.h"

std::string getString(ActionData& action_data, const std::string& prompt){
    std::string response;
    action_data.getOS() << prompt;
    action_data.getIS() >> response;
    return response;
}

int getInteger(ActionData& action_data, const std::string& prompt){
    action_data.getOS() << prompt;
    int response;
    action_data.getIS() >> response;
    return response;


}

double getDouble(ActionData& action_data, const std::string& prompt){
    action_data.getOS() << prompt;
    double response;
    action_data.getIS() >> response;
    return response;

}

int askQuestions3(ActionData& action_data){
    std::string favoriteStr;
    favoriteStr = getString(action_data,"What is your favorite color? ");
    int favoriteInt;
    favoriteInt = getInteger(action_data, "What is your favorite integer? ");
    double favoriteDouble;
    favoriteDouble = getDouble(action_data, "What is your favorite number? ");
  
    for (int i = 1; i <= favoriteInt; i++){
        action_data.getOS() << i << " " << favoriteStr << " " << favoriteDouble << std::endl;

    }

    return favoriteInt;

}

int askInquisitorQuestions( ActionData& action_data ){
    std::string mPP;
    mPP = getString(action_data, "What is your most powerful Pokemon? ");
    int mPL;
    mPL = getInteger(action_data,"What is its level? ");
    double mPH;
    mPH = getDouble(action_data, "What is its Health? ");
    action_data.getOS() << mPP << std::endl;
    action_data.getOS() << mPL << std::endl;
    action_data.getOS() << mPH << std::endl;
    action_data.getOS() << mPP << " is level " << mPL << " and " << mPH << " HP.";
    return mPL;
}

int askUncleBuckQuestions(ActionData& action_data){
    std::string q1;
    q1 = getString(action_data, "Where do you live? ");
    std::string q2;
    q2 = getString(action_data,"Own or rent? ");
    int q3;
    q3 = getInteger(action_data, "What is your record for consecutive questions asked? ");
    //os << q1 << std::endl;
    //os << q2 << std::endl;
    //os << q3 << std::endl;
    std::string response;
    std::string response2;
    if (q3 < 20 && q2 == "rent"){
        response = "okay";
        response2 = ". Enjoy renting in the suburbs.";
    }
    if (q3 > 20 && q2 == "rent"){
        response = "pretty good";
        response2 = ". Enjoy renting in the city.";
    }
        if (q3 < 20 && q2 == "own"){
        response = "okay";
        response2 = ". Enjoy owning in the suburbs.";
    }
    if (q3 > 20 && q2 == "own"){
        response = "pretty good";
        response2 = ". Enjoy owning in the city.";
    }
    action_data.getOS() << q3 << " is " << response << response2;
    return q3;
}

std::string getChoice( ActionData& action_data ){
    return getString(action_data, "Choice? ");
}

void commentLine(ActionData& action_data) {
    char c; // Change the data type to char
    while (action_data.getIS().read(&c, 1)) { // Attempt to read a character and check if it succeeded
        if (action_data.getIS().good() != true || c == '\n'){
            return; // Exit if a newline character is read.
        }
    
    }
    return;
}

void quit(ActionData& action_data){
    action_data.setDone();
}