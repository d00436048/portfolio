#include <iostream>
#include "image_menu.h"

int main(){
    return inquisitor(std::cin, std::cout);
}