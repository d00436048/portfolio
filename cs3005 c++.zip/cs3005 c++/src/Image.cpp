#include "Image.h"

Image::Image()
    :mX(0), mY(0){
    mPixels.resize( mX * mY * 3 );
}

Image::Image(const int& height, const int& width)
       : mX(width), mY(height) {
        mPixels.resize(mX * mY * 3);

}

int Image::getWidth() const {
    return mX;
}

int Image::getHeight() const {
    return mY;
}



bool Image::indexValid( const int& row, const int& column, const int& channel) const {
    if (row >= 0 && column >= 0 && channel >= 0 && row < mY && column < mX && channel < 3){
        return true;
    }
    else{
        return false;
    }
}

int Image::index( const int& row, const int& column, const int& channel ) const {
    int index = (row * mX * 3) + (column * 3) + channel;
    return index;
}

int Image::getChannel( const int& row, const int& column, const int& channel ) const {
    if (indexValid(row,column,channel)){
        return mPixels[index(row, column, channel)];
    }
    else{
        int value = -1;
        return value;
    }
}

void Image::setWidth( const int& width ){
    if (width >= 0){
        mX = width;
        mPixels.resize( mX * mY * 3 );
    }
}

void Image::setHeight( const int& height ){
    if (height >=0){
        mY = height;
        mPixels.resize( mX * mY * 3 );
    }
}

void Image::setChannel( const int& row, const int& column, const int& channel, const int& value ){
    if (indexValid(row,column,channel)){
        mPixels[index(row,column,channel)] = value;
    }
}