#ifndef _ppm_
#define _ppm_

#include <iostream>
#include "Image.h"
#include "ColorTable.h"



class PPM : public Image {
public:
    PPM();
    PPM( const int& height, const int& width );

    int getMaxColorValue( ) const;

    bool valueValid( const int& value) const;

    void setMaxColorValue( const int& max_color_value );

    void setChannel( const int& row, const int& column, const int& channel, const int& value );

    void setPixel( const int& row, const int& column, const int& red, const int& green, const int& blue );

    void writeStream(std::ostream& os) const; 

    //action data assignment
    void readStream(std::istream& is);

    //ppm_operators
    bool operator==( const PPM& rhs ) const;

    bool operator!=( const PPM& rhs ) const; 

    bool operator<( const PPM& rhs ) const;

    bool operator<=( const PPM& rhs ) const;

    bool operator>( const PPM& rhs ) const;

    bool operator>=( const PPM& rhs ) const;

    PPM& operator+=( const PPM& rhs );

    PPM& operator-=( const PPM& rhs );

    PPM& operator*=( const double& rhs );

    PPM& operator/=( const double& rhs );

    PPM operator+( const PPM& rhs ) const;

    PPM operator-( const PPM& rhs ) const;

    PPM operator*( const double& rhs ) const;

    PPM operator/( const double& rhs ) const;

    //practice exam 2
    PPM &operator+=(const int &rhs);

    //image_filters
    void grayFromChannel( PPM& dst, const int& src_channel ) const;
    void grayFromRed( PPM& dst ) const;
    void grayFromGreen( PPM& dst ) const;
    void grayFromBlue( PPM& dst ) const;
    double linearColorimetricPixelValue( const int& row, const int& column ) const;
    void grayFromLinearColorimetric( PPM& dst ) const;

    //exam 2
    void orangeFilter(PPM& dst) const;

private:
    int mColor;



};




#endif /* _ppm_ */