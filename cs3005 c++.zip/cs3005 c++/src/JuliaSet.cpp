#include "JuliaSet.h"
#include <cmath>


JuliaSet::JuliaSet() : ComplexFractal(){
    a_parameter = -0.650492;
    b_parameter = -0.478235;
    //setMaxNumber(255);
}

JuliaSet::JuliaSet( const int& height, const int& width, const double& min_x, const double& max_x, const double& min_y, const double& max_y, const double& a, const double& b ) : ComplexFractal(height, width, min_x, max_x, min_y, max_y){
    a_parameter = a;
    b_parameter = b;
}

JuliaSet::~JuliaSet( ){

}

double JuliaSet::getA( ) const{
    return a_parameter;
}

double JuliaSet::getB( ) const{
    return b_parameter;
}

void JuliaSet::setParameters( const double& a, const double& b ){
    if (a >= -2.0 && a <= 2.0 && b >= -2.0 && b <= 2.0){
        a_parameter = a;
        b_parameter = b;
    }
}

void JuliaSet::calculateNextPoint( const double x0, const double y0, double& x1, double &y1 ) const{
    x1 = x0*x0 - y0*y0 + a_parameter;
    y1 = 2*x0*y0 + b_parameter;
}

int JuliaSet::calculatePlaneEscapeCount( const double& x0, const double& y0 ) const{
    double x1;
    double y1;
    double x2 = x0;
    double y2 = y0;
    double distance = sqrt(x2*x2 + y2*y2);
    int iterations = 0;
    int max_iterations = getMaxNumber();

    for (iterations = 0; iterations < max_iterations; iterations++){
        calculateNextPoint(x2,y2,x1,y1);
        distance = sqrt(x2*x2 + y2*y2);
        x2 = x1;
        y2 = y1;
        if (distance > 2){
            return iterations;
        }
    }
    return iterations;

    // while (distance <= 2 && iterations < max_iterations){
    // calculateNextPoint(x2,y2,x1,y1);
    // x2 = x1;
    // y2 = y1;
    // distance = sqrt(x2*x2 + y2*y2);
    // iterations ++;
    // }
    // return iterations;
}

int JuliaSet::calculateNumber( const int& row, const int& column ) const{
    double x1;
    double y1;
    //double distance;
    if (row < 0 || row >= getHeight() || column < 0 || column >= getWidth()){
        return -1;
    }
    else{
        ComplexFractal::calculatePlaneCoordinatesFromPixelCoordinates(row, column, x1, y1);
        return calculatePlaneEscapeCount(x1, y1);
    }
}
