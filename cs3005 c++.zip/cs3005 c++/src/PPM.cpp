#include "PPM.h"
#include <cmath>


PPM::PPM() : Image(){
    mColor = 1;
}

PPM::PPM( const int& height, const int& width ) : Image (height, width), mColor(1){

}

int PPM::getMaxColorValue( ) const{
    return mColor;
}

bool PPM::valueValid( const int& value ) const{
    if (value >= 0 && value <=mColor){
        return true;
    }
    else{
        return false;
    }
}

void PPM::setMaxColorValue( const int& max_color_value ){
    if (max_color_value >= 1 && max_color_value <= 255){
        mColor = max_color_value;
    }
}

void PPM::setChannel( const int& row, const int& column, const int& channel, const int& value){
        if (valueValid(value)){
            Image::setChannel(row, column, channel, value);
        }
}

void PPM::setPixel( const int& row, const int& column, const int& red, const int& green, const int& blue ){
    Image::setChannel(row, column, 0, red);
    Image::setChannel(row, column, 1, green);
    Image::setChannel(row, column, 2, blue);
}

void PPM::writeStream( std::ostream& os ) const{
    int height = Image::getHeight();
    int width = Image:: getWidth();
    os << "P6 " << width << " " << height << " " << mColor <<"\n";
    //binary of colors for each piexel in same order as color file//
    for (int h = 0; h < height; h++ ){
        for (int w = 0; w < width; w++){
            unsigned char red = Image::getChannel(h, w,0);
            unsigned char  green = Image::getChannel(h, w,1);
            unsigned char  blue = Image::getChannel(h, w, 2);

            os.write((char *) &red, sizeof(red));
            os.write((char *) &green, sizeof(green));
            os.write((char *) &blue, sizeof(blue));

        }
    }
}

void PPM::readStream( std::istream& is ){
    std::string ds;
    is >> ds;
    int height;
    int width;
    is >> width;
    is >> height;
    Image::setHeight(height);
    Image::setWidth(width);
    
    //is >> "P6 " >> width >> " " >> height >> " " >> mColor >>"\n" 
    int maxColor;
    is >> maxColor;
    setMaxColorValue(maxColor);

    is.ignore();
    //binary of colors for each piexel in same order as color file//
    for (int h = 0; h < height; h++ ){
        for (int w = 0; w < width; w++){
            unsigned char red;
            unsigned char  green;
            unsigned char  blue;


            
            is.read((char *) &red, sizeof(red));
            is.read((char *) &green, sizeof(green));
            is.read((char *) &blue, sizeof(blue));

            Image::setChannel(h, w,0, red);
            Image::setChannel(h, w,1, green);
            Image::setChannel(h, w, 2, blue);


        }
    }
}

//ppm operators
bool PPM::operator==( const PPM& rhs ) const{
    return (getWidth() * getHeight() * 3) == (rhs.getWidth() * rhs.getHeight() * 3);
}    

bool PPM::operator!=( const PPM& rhs ) const{
    return (getWidth() * getHeight() * 3) != (rhs.getWidth() * rhs.getHeight() * 3);
}

bool PPM::operator<( const PPM& rhs ) const{
    return (getWidth() * getHeight() * 3) < (rhs.getWidth() * rhs.getHeight() * 3);
}

bool PPM::operator<=( const PPM& rhs ) const{
    return (getWidth() * getHeight() * 3) <= (rhs.getWidth() * rhs.getHeight() * 3);
}

bool PPM::operator>( const PPM& rhs ) const{
    return (getWidth() * getHeight() * 3) > (rhs.getWidth() * rhs.getHeight() * 3);
}

bool PPM::operator>=( const PPM& rhs ) const{
    return (getWidth() * getHeight() * 3) >= (rhs.getWidth() * rhs.getHeight() * 3);
}

PPM& PPM::operator+=( const PPM& rhs ){
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) + rhs.getChannel(row, column, channel);
                if (value > mColor){
                    value = mColor;
                }
                setChannel(row,column,channel,value);
            }
        }
    }
return *this;
}

PPM& PPM::operator-=( const PPM& rhs ){
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) - rhs.getChannel(row, column, channel);
                if (value < 0){
                    value = 0;
                }
                setChannel(row,column,channel,value);
            }
        }
    }
return *this;
}

PPM& PPM::operator*=( const double& rhs ){
     for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) * rhs;
                if (value > mColor){
                    value = mColor;
                }
                else if (value < 0){
                    value = 0;
                }
                setChannel(row,column,channel,value);
            }
        }
    }
return *this;
}


PPM& PPM::operator/=( const double& rhs ){
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) / rhs;
                if (value > mColor){
                    value = mColor;
                }
                else if (value < 0){
                    value = 0;
                }
                setChannel(row,column,channel,value);
            }
        }
    }
return *this;
}

PPM PPM::operator+( const PPM& rhs ) const{
    PPM newObj = PPM(getHeight(), getWidth());
    newObj.setMaxColorValue(mColor);
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) + rhs.getChannel(row, column, channel);
                if (value > mColor){
                    value = mColor;
                }
                newObj.setChannel(row,column,channel,value);
            }
        }
    }
return newObj;
}

PPM PPM::operator-( const PPM& rhs ) const{
    PPM newObj1 = PPM(getHeight(), getWidth());
    newObj1.setMaxColorValue(mColor);
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) - rhs.getChannel(row, column, channel);
                if (value < 0){
                    value = 0;
                }
                newObj1.setChannel(row,column,channel,value);
            }
        }
    }
return newObj1;
}

PPM PPM::operator*( const double& rhs ) const{
    PPM newObj2 = PPM(getHeight(), getWidth());
    newObj2.setMaxColorValue(mColor);
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) * rhs;
                if (value > mColor){
                    value = mColor;
                }
                else if (value < 0){
                    value = 0;
                }
                newObj2.setChannel(row,column,channel,value);
            }
        }
    }
return newObj2;
}

PPM PPM::operator/( const double& rhs ) const{
    PPM newObj3 = PPM(getHeight(), getWidth());
    newObj3.setMaxColorValue(mColor);
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) / rhs;
                if (value > mColor){
                    value = mColor;
                }
                else if (value < 0){
                    value = 0;
                }
                newObj3.setChannel(row,column,channel,value);
            }
        }
    }
return newObj3;
}

//image filters
void PPM::grayFromChannel( PPM& dst, const int &src_channel ) const{
     dst.setHeight(getHeight());
     dst.setWidth(getWidth());
     dst.setMaxColorValue(getMaxColorValue());
    
     for (int row = 0; row <= dst.getHeight(); row++){
         for (int column = 0; column <= dst.getWidth(); column++){
                 int value = getChannel(row, column, src_channel);
                 dst.setPixel(row, column, value, value, value);
         }
     }
 }

 void PPM::grayFromRed( PPM& dst ) const{
     grayFromChannel( dst, 0);
 }

 void PPM::grayFromGreen( PPM& dst ) const{
     grayFromChannel( dst, 1);
 }

 void PPM::grayFromBlue( PPM& dst ) const{
     grayFromChannel( dst, 2);
 }

 double PPM::linearColorimetricPixelValue( const int& row, const int& column ) const{
     int red = getChannel(row, column, 0);
     int green = getChannel(row, column, 1);
     int blue = getChannel(row, column, 2);
     double brightness = 0.2126*red + 0.7152*green + 0.0722*blue;
     return brightness;
 }

 void PPM::grayFromLinearColorimetric( PPM& dst ) const{
     dst.setHeight(getHeight());
     dst.setWidth(getWidth());
     dst.setMaxColorValue(mColor);

     for (int row = 0; row < getHeight(); row++){
         for (int column = 0; column < getWidth(); column++){
             double value = linearColorimetricPixelValue(row, column);
             dst.setChannel(row, column, 0, value);
             dst.setChannel(row, column, 1, value);
             dst.setChannel(row, column, 2, value);
         }
     }
 }

//practice exam 2
PPM& PPM::operator+=( const int& rhs ){
    for (int row = 0; row < getHeight(); row++){
        for (int column = 0; column < getWidth(); column++){
            for( int channel = 0 ; channel < 3; channel++){
                int value = getChannel(row, column,channel) + rhs;
                if (value > mColor){
                    value = mColor;
                }
                else if (value < 0){
                    value = 0;
                }
                setChannel(row,column,channel,value);
            }
        }
    }
return *this;
}


//exam 2
 void PPM::orangeFilter( PPM& dst ) const{
     dst.setHeight(getHeight());
     dst.setWidth(getWidth());
     dst.setMaxColorValue(mColor);

     for (int row = 0; row < getHeight(); row++){
         for (int column = 0; column < getWidth(); column++){
             int old_red = getChannel(row, column, 0);
             int old_green = getChannel(row, column, 1);
             int old_blue = getChannel(row, column, 2);

             int new_red = 2*(2*old_red+old_green)/3;
             int new_green = 2*(2*old_red+old_green)/6;
             int new_blue = old_blue/2;

             if (new_red >= dst.getMaxColorValue()){
                new_red = dst.getMaxColorValue();
             }
             if (new_green >= dst.getMaxColorValue()){
                new_green = dst.getMaxColorValue();
             }
             if (new_blue >= dst.getMaxColorValue()){
                new_blue = dst.getMaxColorValue();
             }
             dst.setPixel(row, column, new_red, new_green, new_blue);
         }
     }
 }