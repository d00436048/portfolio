#ifndef ACTIONDATA
#define ACTIONDATA 



#include <iostream>
#include "PPM.h"
#include "NumberGrid.h"
#include "ColorTable.h"


class ActionData

{ 
    //access specifier//
    public:


    //methods//
    ActionData(std::istream& is, std::ostream& os); 
    std::istream& getIS();
    std::ostream& getOS();
    PPM& getInputImage1();
    PPM& getInputImage2();
    PPM& getOutputImage();
    bool getDone() const;
    void setDone();
    ~ActionData();
    NumberGrid& getGrid();
    void setGrid(NumberGrid *grid);
    ColorTable& getTable();

    

    //data members//
    private:
    std::istream& is;
    std::ostream& os;
    bool done;
    PPM II1;
    PPM II2;
    PPM OI;

    ColorTable cTable;
    NumberGrid* numGrid;



};

#endif