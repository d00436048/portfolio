#include <iostream>
#include "image_menu.h"

int main(){
    return simple_squares_ascii(std::cin, std::cout);
}