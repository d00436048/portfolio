#include <iostream>
#include "image_menu.h"


int main(){
    return assignment2(std::cin, std::cout);
}