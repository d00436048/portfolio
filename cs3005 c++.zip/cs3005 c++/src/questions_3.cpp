#include <iostream>
#include "image_menu.h"

int main(){
    int Num = assignment1(std::cin, std::cout);
    return Num;
}