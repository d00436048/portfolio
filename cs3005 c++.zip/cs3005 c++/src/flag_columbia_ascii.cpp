#include <iostream>
#include "image_menu.h"

int main(){
    return flag_columbia_ascii(std::cin, std::cout);
}