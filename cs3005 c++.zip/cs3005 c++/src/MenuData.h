#ifndef MENUDATA
#define MENUDATA

#include "ActionData.h"
#include <iostream>
#include <map>
#include <vector>
#include <string> 

typedef void (*ActionFunctionType)(ActionData& action_data);

class MenuData{
public:

    //methods//
    MenuData();

    void addAction(const std::string& name, ActionFunctionType func, const std::string& description);

    const std::vector<std::string>& getNames() const;

    ActionFunctionType getFunction(const std::string& name);

    const std::string& getDescription(const std::string& name);


    //data members//

 private:
    std::vector<std::string> Cnames;


    //std::include <type of keys, type of values> name
    std::map<std::string,ActionFunctionType> cnafMap;
    std::map<std::string,std::string> cncdMap;

};

#endif