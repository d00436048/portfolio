#include "ActionData.h"

ActionData::ActionData(std::istream& is, std::ostream& os) : is(is), os(os), done(false), cTable(16), numGrid(0){

    Color colors1 = Color(0,255,0);
    Color colors2 = Color (255,0,255);
    cTable.insertGradient(colors1,colors2,0,15);
}

std::istream& ActionData::getIS(){
    return is;
}

std::ostream& ActionData::getOS(){
    return os;
}

PPM& ActionData::getInputImage1(){
    return II1;
}

PPM& ActionData::getInputImage2(){
    return II2;
}

PPM& ActionData::getOutputImage(){
    return OI;
}

bool ActionData::getDone() const{
    return done;
}

void ActionData::setDone(){
    done = true;
}

ActionData::~ActionData(){
    if (numGrid != 0){
        delete numGrid;
    }
}

NumberGrid& ActionData::getGrid(){
    return *numGrid;
}

void ActionData::setGrid(NumberGrid *grid){
    if (numGrid != 0){
    delete numGrid;
    }
    numGrid = grid;
}

ColorTable& ActionData::getTable(){
     return cTable;
}