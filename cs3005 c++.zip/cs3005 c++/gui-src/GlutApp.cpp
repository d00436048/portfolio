#include "GlutApp.h"
#include "glut_app.h"
#include "image_menu.h"
#include <string.h>

GlutApp::GlutApp(int height, int width)
  : mData(height, width) {

}

void GlutApp::setSize(int height, int width) {
  mData.setSize(height, width);
}

int GlutApp::getHeight() const {
  return mData.getHeight();
}
int GlutApp::getWidth() const {
  return mData.getWidth();
}

void GlutApp::display() {
  std::cout << "calling display with interaction mode: " << mData.getInteractionMode() << std::endl;
  if(mData.getInteractionMode() == mData.IM_FRACTAL){ //maybe not mData infront of IM_Fractal
    displayOutputImage();
  }
  else if(mData.getInteractionMode() == mData.IM_COLORTABLE){ //maybe not mData infront of IM_colortable
    displayColorTable();
  }
  else if (mData.getInteractionMode() == mData.IM_COLOR1){
    displayColorTable();
  }
  else if (mData.getInteractionMode() == mData.IM_COLOR2){
    displayColorTable();
  }
  else if (mData.getInteractionMode() == mData.IM_COLOR3){
    displayColorTable();
  }

}

void GlutApp::displayOutputImage() {
  std::cout << "calling display output image" << std::endl;
  PPM& p = mData.getOutputImage();
  double r, g, b;
  int row, column;
  glBegin( GL_POINTS );
  for(row = 0; row < p.getHeight(); row++){
    for (column = 0; column < p.getWidth(); column++){
      //program is properly calling from ppm object 
      r = p.getChannel(row, column, 0) / 255.0;
      g = p.getChannel(row, column, 1) / 255.0;
      b = p.getChannel(row, column, 2) / 255.0; //could be max?
      glColor3d(r, g, b);
      glVertex2i(column, p.getHeight()-row-1);
    }
  }
  glEnd();
}


void GlutApp::displayColorTable() {
  std::cout << "calling display color table" << std::endl;
  ColorTable& ct = mData.getColorTable();
  double r, g, b;
  std::cout << "number colortable is returning" << ct.getNumberOfColors() << std::endl;

  glBegin(GL_POINTS);
  for (int row = 0; row < getHeight(); row++) {
    for (int column = 0; column < getWidth(); column++) {
      //std::cout << "colortablesize: " << colorTableSize;
      int i = column * ct.getNumberOfColors() / getWidth(); //colortablesize not correct not setting number of colors right
      //cant change colors in colortable for whatever reason???
      //std::cout << " Column: " << column << ", Index: " << i << std::endl;

      r = ct[i].getRed() / 255.0;
      g = ct[i].getGreen() / 255.0;
      b = ct[i].getBlue() / 255.0;
      //std::cout << "RGB: " << ct[i].getRed() << ", " << ct[i].getGreen() << ", " << ct[i].getBlue() << std::endl;

      glColor3d(r, g, b);
      glVertex2i(column, getHeight()-row-1);
    }
  }

  glEnd();
  //glFlush();
}


bool GlutApp::keyboard(unsigned char c){
  bool display_need_update = false;

  if (c == 'J'){
    std::cout << "J pressed in glut app" <<std::endl;
    mData.createJulia1();
    display_need_update = true;
  }
  else if(c == 'j'){
    std::cout << "j pressed in glut app" << std::endl;
    mData.createJulia2();
    display_need_update = true;
  }
  else if(c == 'M'){
    std::cout << "M pressed in glut app" << std::endl;
    mData.createMandelbrot1();
    display_need_update = true;
  }
  else if(c == 'm'){
    std::cout << "m pressed in glut app" << std::endl;
    mData.createMandelbrot2();
    display_need_update = true;
  }
  else if(c == 'C'){
    std::cout << "C pressed in glut app" << std::endl;
    mData.createComplexFractal1();
    display_need_update = true;
  }
  else if(c == 'c'){
    std::cout << "c pressed in glut app" << std::endl;
    mData.createComplexFractal2();
    display_need_update = true;
  }
  else if(c == 'T'){
    std::cout << "T pressed in glut app" << std::endl;
    mData.setInteractionMode(mData.IM_COLORTABLE);
    display_need_update = true;
  }
  else if(c == 't'){
    std::cout << "t pressed in glut app" << std::endl;
    mData.setInteractionMode(mData.IM_FRACTAL);
    display_need_update = true;
  }
  else if(c == 'b'){
    std::cout << "b pressed in glut app" << std::endl;
    mData.setFractalMode(mData.M_MANDELBROT);
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == 'n'){
    std::cout << "n pressed in glut app" << std::endl;
    mData.setFractalMode(mData.M_JULIA);
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == 'F'){
    std::cout << "F pressed in glut app" << std::endl;
    mData.setFractalMode(mData.M_COMPLEX);
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == '>' || c == '.'){
    std::cout << "> or . pressed in glut app" << std::endl;
    mData.increaseColorTableSize();
    display_need_update = true;
  }
  else if(c == '<' || c == ','){
    std::cout << "< or , pressed in glut app" << std::endl;
    mData.decreaseColorTableSize();
    display_need_update = true;
  }
  else if(c == 'r' && mData.getInteractionMode() == mData.IM_COLORTABLE){
    std::cout << "r colortable interaction mode pressed in glut app" << std::endl;
    mData.randomColor1();
    display_need_update = true;
  }
  else if(c == 'R' && mData.getInteractionMode() == mData.IM_COLORTABLE){
    std::cout << "R colortable interaction mode pressed in glut app" << std::endl;
    mData.randomColor2();
    display_need_update = true;
  }
  else if(c == 'z'){
    std::cout << "z pressed in glut app" << std::endl;
    mData.zoomIn();
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == 'Z'){
    std::cout << "Z pressed in glut app" << std::endl;
    mData.zoomOut();
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == 'R' && mData.getInteractionMode() == mData.IM_FRACTAL){
    std::cout << "R  fractal interaction mode pressed in glut app" << std::endl;
    mData.resetPlane();
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == '+' || c == '='){
    std::cout << "+ or = pressed in glut app" << std::endl;
    mData.increaseMaxNumber();
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == '-' || c == '_'){
    std::cout << "- or _ pressed in glut app" << std::endl;
    mData.decreaseMaxNumber();
    mData.createFractal();
    display_need_update = true;
  }
  else if (c == '0'){
    std::cout << "0 pressed in glut app" << std::endl;
    mData.nextColorTableMode();
    display_need_update = true;
  }
  else if (c == '1'){
    std::cout << "1 pressed in glut app" << std::endl;
    mData.setInteractionMode(mData.IM_COLOR1);
    mData.createFractal();
    display_need_update = true;
  }
  else if (c == '2'){
    std::cout << "2 pressed in glut app" << std::endl;
    mData.setInteractionMode(mData.IM_COLOR2);
    mData.createFractal();
    display_need_update = true;
  }
  else if (c == '3'){
    std::cout << "3 pressed in glut app" << std::endl;
    mData.setInteractionMode(mData.IM_COLOR3);
    mData.createFractal();
    display_need_update = true;
  }
  else if (c == 'Y'){
    std::cout << "y pressed in glut app" << std::endl;
    mData.increaseRed();
    display_need_update = true;
  }
  else if (c == 'y'){
    std::cout << "y pressed in glut app" << std::endl;
    mData.decreaseRed();
    display_need_update = true;
  }
  else if (c == 'U'){
    std::cout << "U pressed in glut app" << std::endl;
    mData.increaseGreen();
    display_need_update = true;
  }
  else if (c == 'u'){
    std::cout << "2 pressed in glut app" << std::endl;
    mData.decreaseGreen();
    display_need_update = true;
  }
  else if (c == 'I'){
    std::cout << "I pressed in glut app" << std::endl;
    mData.increaseBlue();
    display_need_update = true;
  }
  else if (c == 'i'){
    std::cout << "i pressed in glut app" << std::endl;
    mData.decreaseBlue();
    display_need_update = true;
  }
  else if (c == 'e'){
    std::cout << "e pressed" << std::endl;
    mData.randomColor3();
    display_need_update = true;
  }

  return display_need_update;
}

bool GlutApp::special(unsigned char c){
  bool display_need_update = false;
  if(c == GLUT_KEY_LEFT){ //if pass in literal character string then do 'left arrow' etc... not GLUT_KEY_LEFT
    std::cout << "LEFT ARROW pressed in glut app" << std::endl;
    mData.moveLeft();
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == GLUT_KEY_RIGHT){
    std::cout << "RIGHT ARROW pressed in glut app" << std::endl;
    mData.moveRight();
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == GLUT_KEY_DOWN){
    std::cout << "DOWN ARROW pressed in glut app" << std::endl;
    mData.moveDown();
    mData.createFractal();
    display_need_update = true;
  }
  else if(c == GLUT_KEY_UP){
    std::cout << "UP ARROW pressed in glut app" << std::endl;
    mData.moveUp();
    mData.createFractal();
    display_need_update = true;
  } 
  return display_need_update;
}

bool GlutApp::mouse(int mouse_button, int state, int x, int y){
  bool display_need_update = false;
  if (mouse_button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && 0 < x && x < mData.getWidth() && 0 < y && y < mData.getHeight()){
    std::cout << "MOSUEPRESSED in glut app" << std::endl;
    if(mData.getFractalMode() == mData.M_COMPLEX){
      mData.setAB(0.8, 0.8);
      mData.setFractalMode(mData.M_JULIA);
      mData.createFractal();
      display_need_update = true;
    }
    else if(mData.getFractalMode() == mData.M_MANDELBROT){
      mData.setAB(0.8, 0.8);
      mData.setFractalMode(mData.M_JULIA);
      mData.createFractal();
      display_need_update = true;
    }
  }
  return display_need_update;
}