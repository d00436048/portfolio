#include "AppData.h"
#include "image_menu.h"
#include <string>

AppData::AppData(int height, int width) 
  : mHeight(height), mWidth(width), mMaxNumber(255), mInteractionMode(IM_FRACTAL), mFractalMode(M_JULIA), mNumColor(50), mColor1(230,0,0), mColor2(0,255,0), mColor3(0,0,255), mMinX(-2.0), mMaxX(2.0), mMinY(-2.0), mMaxY(2.0), mA(-0.835), mB(-0.2321),
   
   mActionData(mInputStream, mOutputStream), mDebug(1){
  
  // mMaxNumber = 255;

  // mActionData.getTable().setNumberOfColors(2);
  // mActionData.getTable().setRandomColor(255,0);
  // mActionData.getTable().setRandomColor(255,1);
  // mColor1 = mActionData.getTable()[0];
  // mColor2 = mActionData.getTable()[1];

  configureMenu(mMenuData);
  
  mActionData.setGrid(new ComplexFractal()); //should this be put at top of function

  setColorTable();

  createFractal();
}

void AppData::setSize(int height, int width) {
  mHeight = height;
  mWidth = width;
}

int AppData::getHeight() const {
  return mHeight;
}

int AppData::getWidth() const {
  return mWidth;
}

PPM& AppData::getOutputImage(){
  return mActionData.getOutputImage();
}

ColorTable& AppData::getColorTable(){
  return mActionData.getTable();
}

void AppData::createJulia1(){

  std::cout << "createJulia1 ran" << std::endl;

  selectJulia();

  configureGrid(200);

  juliaParameters(0.285, 0.01);

  fractalPlaneSize(-2.0, 2.0, -2.0, 2.0);

  fractalCalculate();

  setColorTable();

  gridApplyColorTable();
//--------------------------------------the above section of code is almost correct check configure grid for proper parameter passing------------------

}

void AppData::createJulia2(){

  std::cout << "createjulia2 ran" << std::endl;

  selectJulia();

  configureGrid(150);

  juliaParameters(-0.835, -0.2321);

  fractalPlaneSize(-1.5, 1.5, -1.5, 1.5);

  fractalCalculate();

  setColorTable();

  gridApplyColorTable();
}

void AppData::createMandelbrot1(){

  std::cout << "createmandelbrot1 ran" << std::endl;

  selectMandelbrot();

  configureGrid(200);

  fractalPlaneSize(-2.0, 2.0, -2.0, 2.0);

  fractalCalculate();

  setColorTable();

  gridApplyColorTable();

}

void AppData::createMandelbrot2(){

  std::cout << "createmandelbrot2 ran" << std::endl;

  selectMandelbrot();

  configureGrid(100);

  fractalPlaneSize(-1, 1, -1, 1);

  fractalCalculate();

  setColorTable();

  gridApplyColorTable();

}

void AppData::createComplexFractal1(){
  selectComplexFractal();
  configureGrid(200);
  fractalPlaneSize(-1.5, 1.5, -1.5, 1.5);
  fractalCalculate();
  setColorTable();
  gridApplyColorTable();
}

void AppData::createComplexFractal2(){
  selectComplexFractal();
  configureGrid(150);
  fractalPlaneSize(-2.0, 2.0, -2.0, 2.0);
  fractalCalculate();
  setColorTable();
  gridApplyColorTable();
}

void AppData::clearStreams(){
  mInputStream.clear();
  mInputStream.str("");
  mOutputStream.clear();
  mOutputStream.str("");
}

void AppData::runCommand(const std::string& choice){
  if (mDebug != 0){
    std::cout << choice << std::endl;
    std::string inputString = mInputStream.str();
    std::cout << inputString << std::endl; //maybe actiondata.getos() << choice;
    takeAction(choice, mMenuData, mActionData); //is this correct?
    std::string outputString = mOutputStream.str();
    std::cout << outputString << std::endl;
  }
  else{
    takeAction(choice, mMenuData, mActionData);
  }
}

void AppData::selectJulia(){
  clearStreams();
  runCommand("julia");
  std::cout << "select julia called" <<std::endl;
}

void AppData::selectMandelbrot(){
  clearStreams();
  runCommand("mandelbrot");
  std::cout << "select mandelbrot called" <<std::endl;
}

void AppData::selectComplexFractal(){
  clearStreams();
  runCommand("complex-fractal");
  std::cout << "select complexfractal called" <<std::endl;
}

void AppData::configureGrid(int max){ //-------------------------------------------proper parameter passing demonstrated here copy createjulia1 and configrue gird to achieve all keybindings and terminal commands--------------------
  clearStreams();
  std::stringstream temp_stringstream;
  temp_stringstream << mHeight << " " << mWidth << " " << max;
  mInputStream.str(temp_stringstream.str());
  runCommand("grid");
  std::cout << "configuregrid called" <<std::endl;
}

void AppData::juliaParameters(double a, double b){
  clearStreams();
  std::stringstream temp_stringstream;
  temp_stringstream << a << " " << b;
  mInputStream.str(temp_stringstream.str()); 
  runCommand("julia-parameters");
  std::cout << "juliaparameters called" << std::endl;
}

void AppData::fractalPlaneSize(double x_min, double x_max, double y_min, double y_max){
  clearStreams();
  std::stringstream temp_stringstream1;
  temp_stringstream1 << x_min << " " << x_max << " " << y_min << " " << y_max;
  mInputStream.str(temp_stringstream1.str()); 
  runCommand("fractal-plane-size");
  std::cout << "fractalplanesize called" << std::endl;
}

void AppData::fractalCalculate(){
  clearStreams();
  runCommand("fractal-calculate");
  std::cout << "fractalcalculate" << std::endl;
}

void AppData::gridApplyColorTable(){
  clearStreams();
  runCommand("grid-apply-color-table");
  std::cout << "gridapplycolortable called" << std::endl;
}

void AppData::setInteractionMode(InteractionMode mode){
  mInteractionMode = mode;
  std::cout << "setinteractionmode called with: " << mode << std::endl;
}

AppData::InteractionMode AppData::getInteractionMode() const{
return mInteractionMode;
}

void AppData::setColorTable(){
  clearStreams();
  std::stringstream temp_stringstream2;
  temp_stringstream2 << mNumColor;
  mInputStream.str(temp_stringstream2.str()); 
  runCommand("set-color-table-size");
  std::cout << "setColorTable mNumColor after command has been run "<< mNumColor << std::endl;

  clearStreams();
  std::stringstream temp_stringstream3;
  temp_stringstream3 << "0 " << mColor1.getRed() << " " << mColor1.getGreen() << " " << mColor1.getBlue() << " " << mNumColor/2 << " " << mColor2.getRed() << " " << mColor2.getGreen() << " " << mColor2.getBlue(); //maybe needs to be mnumcolor instead of maxnumber-----------------------------------------set-color-table-size
  mInputStream.str(temp_stringstream3.str()); 
  runCommand("set-color-gradient");

  clearStreams();
  std::stringstream tmp61;
  tmp61 << (mNumColor/2) << " " << mColor2.getRed() << " " << mColor2.getGreen() << " " << mColor2.getBlue() << " " << mNumColor-1 << " " << mColor3.getRed() << " " << mColor3.getGreen() << " " << mColor3.getBlue(); //maybe needs to be mnumcolor instead of maxnumber-----------------------------------------set-color-table-size
  mInputStream.str(tmp61.str()); 
  runCommand("set-color-gradient");


  if (mColorTableMode == CT_RANDOM3){
    set3RandomColors();
  }
  if (mColorTableMode == CT_RANDOM){
    setAllRandomColors();
  }
  if (mColorTableMode == CT_REVERSE){
    setReverseGradient();
  }
  //std::cout << "setcolortable called" < "c1 rgb c2 rgb mnumcolor: " << mColor1.getRed() << " " << mColor1.getGreen() << " " << mColor1.getBlue() << " " << mColor2.getRed() << " " << mColor2.getGreen() << " " << mColor2.getBlue() << " " << mMaxNumber << std::endl;
}

void AppData::decreaseColorTableSize(){
  if (mNumColor > 10){
    mNumColor = mNumColor / 1.1;
  }
  setColorTable();
  gridApplyColorTable();
  std::cout << "decreasecolortablesize called" << std::endl;
}

void AppData::increaseColorTableSize(){
  if (mNumColor < 1024){
    mNumColor = mNumColor * 1.1;
  }
  setColorTable();
  gridApplyColorTable();
  std::cout << "increasecolortablesize called" << std::endl;
}

void AppData::randomColor1() {
  getColorTable().setRandomColor( 255, 0);
  mColor1 = getColorTable()[0];

  setColorTable();
  gridApplyColorTable();
  std::cout << "setrandomcolor1 called" << std::endl;
}

void AppData::randomColor2() {
  getColorTable().setRandomColor( 255, mNumColor/2);
  mColor2 = getColorTable()[mNumColor/2];

  setColorTable();
  gridApplyColorTable();
  std::cout << "setrandomcolor2 called" << std::endl;
}

void AppData::randomColor3() {
  getColorTable().setRandomColor( 255, mNumColor-1);
  mColor3 = getColorTable()[mNumColor-1];

  setColorTable();
  gridApplyColorTable();
  std::cout << "setrandomcolor3 called" << std::endl;
}

void AppData::zoomIn(){
  double dx = (1.0 - 0.9)*(mMaxX - mMinX) / 2.0;
  mMinX += dx;
  mMaxX -= dx;

  double dy = (1.0 - 0.9)*(mMaxY - mMinY) / 2.0;
  mMinY += dy;
  mMaxY -= dy;
  std::cout << "zoomin called" << std::endl;
}

void AppData::zoomOut() {
  double dx = (1.0 - 0.9) * (mMaxX - mMinX) / 2.0;
  double dy = (1.0 - 0.9) * (mMaxY - mMinY) / 2.0;

  if (mMinX - dx > -2.0 && mMaxX + dx < 2.0 && mMinY - dy > -2.0 && mMaxY + dy < 2.0) {
    mMinX -= dx;
    mMaxX += dx;
    mMinY -= dy;
    mMaxY += dy;
    std::cout << "zoomout called" << std::endl;
  }
}

void AppData::moveLeft(){
  double dx = (1.0 - 0.9)*(mMaxX-mMinX) / 2.0;
  if (mMinX - dx >= -2.0){
    mMinX -= dx;
    mMaxX -= dx;
    std::cout << "moveleft called" << std::endl;
  }
}

void AppData::moveRight(){
  double dx = (1.0 - 0.9)*(mMaxX-mMinX) / 2.0;
  if (mMinX - dx >= -2.0){  //maybe add instead of minus here
    mMinX += dx;
    mMaxX += dx;
    std::cout << "moveright called" << std::endl;
  }
}

void AppData::moveDown(){
  double dy = (1.0 - 0.9)*(mMaxY-mMinY) / 2.0;
  if (mMinY - dy >= -2.0){
    mMinY -= dy;
    mMaxY -= dy;
    std::cout << "movedown called" << std::endl;
  }
}

void AppData::moveUp(){
  double dy = (1.0 - 0.9)*(mMaxY-mMinY) / 2.0;
  if (mMinY - dy >= -2.0){
    mMinY += dy;
    mMaxY += dy;
    std::cout << "moveup called" << std::endl;
  }
}

void AppData::setFractalMode(FractalMode mode){
  mFractalMode = mode;
  std::cout << "setFractalMode called:  " << mode << std::endl;
}

AppData::FractalMode AppData::getFractalMode() const{
  return mFractalMode;
  std::cout << "getFractalMode called: " << std::endl;
}

void AppData::increaseMaxNumber(){
  if (mMaxNumber < 2048){
    mMaxNumber *= 1.1;
    std::cout << "increaseMaxNumber called: " << mMaxNumber << std::endl;
  }
}

void AppData::decreaseMaxNumber(){
  if (mMaxNumber > 11){
    mMaxNumber /= 1.1;
    std::cout << "decreaseMaxNumber called: " << mMaxNumber << std::endl;
  }
}

void AppData::setAB(int x, int y){ // is this correct?-----------------------------------------------------------------------------
  if (mFractalMode == M_MANDELBROT) {
    ComplexFractal *point = dynamic_cast<ComplexFractal *>(&mActionData.getGrid());
    if (point != nullptr) {
      mA = mMinX + x * point->getDeltaX();
      mB = mMinY + y * point->getDeltaY();
    }
  }
}

void AppData::resetPlane(){
  if (mInteractionMode == IM_FRACTAL){
    mMinX = -2.0;
    mMinY = -2.0;
    mMaxX = 2.0;
    mMaxY = 2.0;
  std::cout << "resetPlane called" << std::endl;
  }
}

void AppData::createFractal(){
    if (mFractalMode == M_MANDELBROT){
      selectMandelbrot();
      std::cout << "createFractal called m_mandelbrot" << std::endl;
    }
    else if(mFractalMode == M_JULIA){
      selectJulia();
      juliaParameters(mA, mB);
      std::cout << "createFractal called m_julia" << std::endl;
    }
    else if (mFractalMode == M_COMPLEX){
      selectComplexFractal();
      std::cout << "createFractal called m_complex" << std::endl;
    }
    configureGrid(mMaxNumber);
    fractalPlaneSize(mMinX, mMaxX, mMinY, mMaxY);
    setColorTable();
    fractalCalculate();
    gridApplyColorTable();
}

//practice exam 4
  void AppData::nextColorTableMode(){
    if (mColorTableMode == CT_GRADIENT){
      mColorTableMode = CT_RANDOM3;
    }
    else if (mColorTableMode == CT_RANDOM3){
      mColorTableMode = CT_RANDOM;  
    }
    else if (mColorTableMode == CT_RANDOM){
      mColorTableMode = CT_REVERSE;
    }
    else if (mColorTableMode == CT_REVERSE){
      mColorTableMode = CT_GRADIENT;
    }

    setColorTable();
    gridApplyColorTable();
  }

  AppData::ColorTableMode AppData::getColorTableMode() const{
    return mColorTableMode;
  }
  void AppData::set3RandomColors(){
  clearStreams();
  std::stringstream temp_stringstream5;
  temp_stringstream5 << 0;
  mInputStream.str(temp_stringstream5.str()); 
  runCommand("set-random-color");

  clearStreams();
  temp_stringstream5 << mActionData.getTable().getNumberOfColors()/2;
  mInputStream.str(temp_stringstream5.str());
  runCommand("set-random-color");

  clearStreams();
  std::stringstream tmp45;
  tmp45 << mActionData.getTable().getNumberOfColors()-1;
  mInputStream.str(tmp45.str());
  runCommand("set-random-color");
  }

  void AppData::setAllRandomColors(){
    for (int i = 0; i < mActionData.getTable().getNumberOfColors(); i++){
      clearStreams();
      std::stringstream tmp50;
      tmp50 << i;
      mInputStream.str(tmp50.str());
      runCommand("set-random-color");
    }

  }

void AppData::setReverseGradient(){
  clearStreams();
  std::stringstream tmp55;

  tmp55 << "0 " << mColor1.getRed() << " " << mColor1.getGreen() << " " << mColor1.getBlue() << " " << mNumColor/2 << " " << mColor2.getRed() << " " << mColor2.getGreen() << " " << mColor2.getBlue(); //maybe needs to be mnumcolor instead of maxnumber-----------------------------------------set-color-table-size
  mInputStream.str(tmp55.str()); 
  runCommand("set-color-gradient");

  clearStreams();
  std::stringstream tmp60;
  tmp60 << (mNumColor/2) << " " << mColor2.getRed() << " " << mColor2.getGreen() << " " << mColor2.getBlue() << " " << mNumColor-1 << " " << mColor1.getRed() << " " << mColor1.getGreen() << " " << mColor1.getBlue(); //maybe needs to be mnumcolor instead of maxnumber-----------------------------------------set-color-table-size
  mInputStream.str(tmp60.str()); 
  runCommand("set-color-gradient");
}

//exam 4
void AppData::increaseChannel(Color& color, int channel){
  if (color == mColor1){
    if (channel == 0){
      mColor1.setRed(mColor1.getRed()+10);
      if (mColor1.getRed() > 255){
        mColor1.setRed(255);
      }
    }
    else if (channel == 1){
      mColor1.setGreen(mColor1.getGreen()+10);
      if (mColor1.getGreen() > 255){
        mColor1.setGreen(255);
      }
    }
    else if (channel == 2){
      mColor1.setBlue(mColor1.getBlue()+10);
      if (mColor1.getBlue() > 255){
        mColor1.setBlue(255);
      }
    }
  }

  else if (color == mColor2){
    if (channel == 0){
      mColor2.setRed(mColor2.getRed()+10);
      if (mColor2.getRed() > 255){
        mColor2.setRed(255);
      }
    }
    else if (channel == 1){
      mColor2.setGreen(mColor2.getGreen()+10);
      if (mColor2.getGreen() > 255){
        mColor2.setGreen(255);
      }
    }
    else if (channel == 2){
      mColor2.setBlue(mColor2.getBlue()+10);
      if (mColor2.getBlue() > 255){
        mColor2.setBlue(255);
      }
    }
  }
  setColorTable();
  gridApplyColorTable();
}
 
void AppData::decreaseChannel(Color& color, int channel){
    if (color == mColor1){
      if (channel == 0){
        mColor1.setRed(mColor1.getRed()-10);
        if (mColor1.getRed() < 0){
          mColor1.setRed(0);
        }
      }
      else if (channel == 1){
        mColor1.setGreen(mColor1.getGreen()-10);
        if (mColor1.getGreen() < 0){
          mColor1.setGreen(0);
        }
      }
      else if (channel == 2){
        mColor1.setBlue(mColor1.getBlue()-10);
        if (mColor1.getBlue() < 0){
          mColor1.setBlue(0);
        }
      }
    }

    else if (color == mColor2){
      if (channel == 0){
        mColor2.setRed(mColor2.getRed()-10);
        if (mColor2.getRed() < 0){
          mColor2.setRed(0);
        }
      }
      else if (channel == 1){
        mColor2.setGreen(mColor2.getGreen()-10);
        if (mColor2.getGreen() < 0){
          mColor2.setGreen(0);
        }
      }
      else if (channel == 2){
        mColor2.setBlue(mColor2.getBlue()-10);
        if (mColor2.getBlue() < 0){
          mColor2.setBlue(0);
        }
      }
    }

    else if (color == mColor3){
      if (channel == 0){
        mColor3.setRed(mColor3.getRed()-10);
        if (mColor3.getRed() < 0){
          mColor3.setRed(0);
        }
      }
      else if (channel == 1){
        mColor3.setGreen(mColor3.getGreen()-10);
        if (mColor3.getGreen() < 0){
          mColor3.setGreen(0);
        }
      }
      else if (channel == 2){
        mColor3.setBlue(mColor3.getBlue()-10);
        if (mColor3.getBlue() < 0){
          mColor3.setBlue(0);
        }
      }
    }

  setColorTable();
  gridApplyColorTable();
 }

  Color& AppData::fetchColor(){
    if (mInteractionMode == IM_COLOR1){
      return mColor1;
    }
    else if (mInteractionMode == IM_COLOR2){
      return mColor2;
    }
    else if (mInteractionMode == IM_COLOR3){
      return mColor3;
    }
    else{
      static Color newColor = {0,255,0};
      return newColor;
    }
  }

  void AppData::increaseRed(){
    increaseChannel(fetchColor(), 0);
  }

  void AppData::decreaseRed(){
    decreaseChannel(fetchColor(), 0);
  }

  void AppData::increaseGreen(){
    increaseChannel(fetchColor(), 1);
  }

  void AppData::decreaseGreen(){
    decreaseChannel(fetchColor(), 1);
  }

  void AppData::increaseBlue(){
    increaseChannel(fetchColor(), 2);
  }

  void AppData::decreaseBlue(){
    decreaseChannel(fetchColor(), 2);
  }