package com.example.apitest

import com.example.afinal.api.ImaggaApiService
import retrofit2.Retrofit
import retrofit2.create
import retrofit2.converter.scalars.ScalarsConverterFactory

class ImaggaResponseFragment {
    private val imaggaApi: ImaggaApiService

    init {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://api.imagga.com/v2/")
            .addConverterFactory(ScalarsConverterFactory.create())
            .build()

        imaggaApi = retrofit.create<ImaggaApiService>()
    }

    suspend fun getTags(imgUrl: String) = imaggaApi.getTags(imgUrl)
}