package com.example.afinal.api

data class Tag(
    val confidence: Double,
    val tag: TagData
)

data class TagData(
    val en: String
)

data class ApiResponse(
    val result: ResultData
)

data class ResultData(
    val tags: List<Tag>
)

