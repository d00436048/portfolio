package com.example.apitest

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.apitest.ResponseActivity
import com.squareup.picasso.Picasso
import kotlinx.coroutines.launch
import org.json.JSONObject

private const val TAG = "secondActivity"
private const val YOUR_API_KEY = "acc_bfcaa0156876892" // Replace with your actual API key
//val image_url = "https://i.pinimg.com/736x/4b/36/05/4b3605d3d1883331c7faabf42f592af4.jpg"
class secondActivity : AppCompatActivity() {

    private val responseViewModel: ResponseViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_layout)

        val imgUrl = intent.getStringExtra("IMAGE_URL")
        val imageView = findViewById<ImageView>(R.id.imageView2)

        if (imgUrl != null) {
            lifecycleScope.launch {
                try {
                    val response = ImaggaResponseFragment().getTags(imgUrl!!)
                    responseViewModel.responseData = response
                    Log.d(TAG, "response received: $response")

                    val responseData = responseViewModel.responseData
                    Log.d(TAG, "response in viewmodel: ${responseData}")

                } catch (e: Exception) {
                    Log.e(TAG, "invalid url")
                }

                Picasso.get()
                    .load(imgUrl)
                    .error(R.drawable.placeholder_image)
                    .into(imageView, object : com.squareup.picasso.Callback {
                        override fun onSuccess(){
                            val tagText = findViewById<TextView>(R.id.tag_text)
                            val perText = findViewById<TextView>(R.id.per_text)
                            val conText = findViewById<TextView>(R.id.con_text)

                            val responseData = responseViewModel.responseData


                            val jsonObject = try {
                                JSONObject(responseData)
                            } catch (e: Exception) {
                                null
                            }

                            // Check if parsing was successful and the object has the expected structure
                            if (jsonObject != null && jsonObject.has("result") && jsonObject.getJSONObject("result").has("tags")) {
                                val tagsJsonArray =
                                    jsonObject.getJSONObject("result").getJSONArray("tags")

                                // If there are any tags, get the most confident one
                                if (tagsJsonArray.length() > 0) {
                                    var mostConfidentTag = tagsJsonArray.getJSONObject(0)
                                    var highestConfidence = 0.0
                                    for (i in 0 until tagsJsonArray.length()) {
                                        val currentTagObject = tagsJsonArray.getJSONObject(i)
                                        val currentConfidence =
                                            currentTagObject.getDouble("confidence")
                                        if (currentConfidence > highestConfidence) {
                                            mostConfidentTag = currentTagObject
                                            highestConfidence = currentConfidence
                                        }
                                    }

                                    val firstTagName =
                                        mostConfidentTag.getJSONObject("tag").getString("en")
                                    val confidencePercentage =
                                        (highestConfidence).toInt().toString() + "%"
                                    tagText.text = firstTagName
                                    perText.text = confidencePercentage

                                }
                            }
                            conText.text = "Confidence:"

                        }
                        override fun onError(e: Exception?){
                            val button = findViewById<Button>(R.id.button2)
                            val tagText = findViewById<TextView>(R.id.tag_text)
                            val perText = findViewById<TextView>(R.id.per_text)
                            val conText = findViewById<TextView>(R.id.con_text)

                            button.visibility = View.INVISIBLE
                            tagText.text = "Invalid Image:"
                            conText.text = ""
                            perText.text = ""


                        }
                    })
//            performAutoTagging(imgUrl)

            }

        } else {
            Log.d(TAG, "Image URL is null")
        }

        val button = findViewById<Button>(R.id.back_button)
        button.setOnClickListener {
            val intent = Intent(this@secondActivity, MainActivity::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_left, R.anim.slide_right)
        }

        val button2 = findViewById<Button>(R.id.button2)
        button2.setOnClickListener {
            //fragmentstuff
            val intent = Intent(this@secondActivity, ResponseActivity::class.java)
            intent.putExtra("Query", responseViewModel.responseData)
            startActivity(intent)
        }
    }
}

//
//private fun performAutoTagging(imageData: String) {
//    //val imageData = "https://docs.imagga.com/static/images/docs/sample/japan-605234_1280.jpg" // URL of the image to be tagged
//
//    Log.d("image url data: ", imageData)
//
//    val apiKey = "$API_KEY"
//    val basicAuth = "Basic " + Base64.encodeToString(apiKey.toByteArray(), Base64.NO_WRAP)
//
//    val api = Retrofit.Builder()
//        .baseUrl(BASE_URL)
//        .addConverterFactory(GsonConverterFactory.create())
//        .client(
//            OkHttpClient.Builder()
//                .addInterceptor { chain ->
//                    val request = chain.request().newBuilder()
//                        .addHeader("Authorization", basicAuth)
//                        .build()
//                    chain.proceed(request)
//                }
//                .build()
//        )
//        .build()
//        .create(MyApi::class.java)
//
//    val requestBody = "{\"image_url\": \"$imageData\"}".toRequestBody("application/json".toMediaType())
//
//    api.autoTagImage(requestBody).enqueue(object : Callback<ResponseData> {
//        override fun onResponse(
//            call: Call<ResponseData>,
//            response: Response<ResponseData>
//        ) {
//            if (response.isSuccessful) {
//                response.body()?.let { responseData ->
//                    for (tag in responseData.result) {
//                        Log.d(TAG, "TAG: ${tag.tag.en}, Confidence: ${tag.confidence}")
//                    }
//                }
//            } else {
//                Log.d(TAG, "ERROR IN API CALL: ${response.code()} - ${response.message()} & ${response.errorBody()?.string()}")
//            }
//        }
//
//        override fun onFailure(call: Call<ResponseData>, t: Throwable) {
//            Log.d(TAG, "Error in API call: ${t.message}")
//        }
//    })
//}
//
//
