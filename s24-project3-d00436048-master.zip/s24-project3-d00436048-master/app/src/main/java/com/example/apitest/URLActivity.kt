package com.example.apitest

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.apitest.R.layout.fragment_url_actrivty

class URLActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(fragment_url_actrivty)

        // Get the FragmentManager
        val fragmentManager = supportFragmentManager

        // Begin a new fragment transaction
        val transaction = fragmentManager.beginTransaction()

        // Create a new instance of UrlDetailFragment
        val fragment: Fragment = UrlDetailFragment()

        // Replace the fragment container with the UrlDetailFragment
        transaction.replace(R.id.fragment_container, fragment)

        // Commit the transaction
        transaction.commit()
    }
}