package com.example.apitest

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private val BASE_URL = "https://api.imagga.com/v2/tags/"
    private val TAG: String = "CHECK_RESPONSE"
    private val API_KEY = "acc_bfcaa0156876892:a80d0dbb762d878ec8cf63605d3c80ed"
    private val API_SECRET = "your_api_secret" // Your Imagga API secret

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.mainPageButton)
        val button4 = findViewById<Button>(R.id.Button4)
        val button3 = findViewById<Button>(R.id.url_button)
        val editText = findViewById<EditText>(R.id.editTextText)

        button.setOnClickListener {
            val imgUrl = editText.text.toString()

            if (imgUrl.isNotEmpty()) {
                if (imgUrl.contains(".jpg") || imgUrl.contains(".jpeg") || imgUrl.contains(".png")) {
                    // Call performAutoTagging method with the retrieved image URL
                    val intent = Intent(this@MainActivity, secondActivity::class.java)
                    intent.putExtra("IMAGE_URL", imgUrl)
                    startActivity(intent)
                    overridePendingTransition(R.anim.slide_left, R.anim.slide_right)
                } else {
                    Toast.makeText(this, "must be jpg or png", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Handle the case where imageUrl is null or empty
                Log.d(TAG, "Image URL is empty please add a URL")
                Toast.makeText(this, "URL cannot be empty", Toast.LENGTH_SHORT).show()

            }
        }

        button4.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

            try {
                startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                // Handle the case where there is no camera app
                Toast.makeText(this, "No camera app available", Toast.LENGTH_SHORT).show()
            }
        }


        button3.setOnClickListener {
            val intent = Intent(this@MainActivity, URLActivity::class.java)
            startActivity(intent)
        }
    }
}