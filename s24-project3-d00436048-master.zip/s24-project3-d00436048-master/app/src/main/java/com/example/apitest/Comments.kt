package com.example.apitest

data class Tag(
    val confidence: Double,
    val tag: TagDetail
)

data class TagDetail(
    val en: String
)

data class ResponseData(
    val result: List<Tag>
)