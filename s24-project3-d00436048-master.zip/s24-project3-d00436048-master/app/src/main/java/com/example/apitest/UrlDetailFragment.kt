package com.example.apitest

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.apitest.databinding.FragmentUrlDetailBinding

private val BASE_URL = "https://api.imagga.com/v2/tags/"
private val TAG: String = "CHECK_RESPONSE"
private val API_KEY = "acc_bfcaa0156876892:a80d0dbb762d878ec8cf63605d3c80ed"
private val API_SECRET = "your_api_secret" // Your Imagga API secret

class UrlDetailFragment : Fragment() {

    private lateinit var binding: FragmentUrlDetailBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            FragmentUrlDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.urlButton.setOnClickListener {
            val url = "https://postimages.org" // Replace with your desired URL
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }

        binding.mainPageButton.setOnClickListener {
            val imgUrl = binding.editTextText.text.toString()

            if (imgUrl.isNotEmpty()) {
                if (imgUrl.contains(".jpg") || imgUrl.contains(".jpeg") || imgUrl.contains(".png")) {
                    // Call performAutoTagging method with the retrieved image URL
                    val intent = Intent(requireContext(), secondActivity::class.java)
                    intent.putExtra("IMAGE_URL", imgUrl)
                    startActivity(intent)
                } else {
                    Toast.makeText(context, "must be jpg or png", Toast.LENGTH_SHORT).show()
                }
            } else {
                // Handle the case where imageUrl is null or empty
                Log.d(TAG, "Image URL is empty please add a URL")
                Toast.makeText(context, "URL cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }

        binding.Button4.setOnClickListener {
            val intent = Intent(requireContext(), MainActivity::class.java)
            startActivity(intent)
        }
    }
}