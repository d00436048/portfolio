package com.example.afinal.api

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query

interface ImaggaApiService {

    @Headers("Authorization: Basic YWNjX2JmY2FhMDE1Njg3Njg5MjphODBkMGRiYjc2MmQ4NzhlYzhjZjYzNjA1ZDNjODBlZA==")
    @GET("tags/")
    suspend fun getTags(
        @Query("image_url") imageUrl: String
    ): String
}