package com.example.apitest

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ResponseAdapter(private val dataList: List<String>) :
    RecyclerView.Adapter<ResponseAdapter.ResponseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ResponseViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_response, parent, false)
        return ResponseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ResponseViewHolder, position: Int) {
        val responseData = dataList[position]
        holder.bind(responseData)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    inner class ResponseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val responseTextView: TextView = itemView.findViewById(R.id.response_text)

        fun bind(responseData: String) {
            responseTextView.text = responseData
        }
    }
}