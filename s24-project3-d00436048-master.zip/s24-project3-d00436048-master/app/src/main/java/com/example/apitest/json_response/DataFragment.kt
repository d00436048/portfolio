package com.example.apitest.json_response

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.apitest.R
import com.example.apitest.databinding.FragmentUrlActrivtyBinding
import com.example.apitest.databinding.FragmentUrlDetailBinding

class DataFragment : Fragment() {

    private var _binding: FragmentUrlActrivtyBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "Cannot access binding because it is null. Is the view visible?"
        }

    private val DataFragmentViewModel: RecyclerViewModel by viewModels()


    private var textString: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            textString = it.getString("text_data") // Retrieve the string from arguments
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.item_response, container, false)

        // Update the text view in item_response.xml with textString
        val textView = view.findViewById<TextView>(R.id.response_text) // Replace with your text view ID
        textView.text = textString

        return view
    }
}