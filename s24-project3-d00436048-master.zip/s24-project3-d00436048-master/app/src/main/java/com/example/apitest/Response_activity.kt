package com.example.apitest

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson


class ResponseActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var stringAdapter: StringAdapter
    private lateinit var dataList: List<String> // List to hold your strings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_response)

        val query = intent.getStringExtra("Query")

        dataList = splitByQuotes(query)// Replace with actual data extraction

//
//        // Retrieve the value of "Query" from the intent extras
//        val responseData = intent.getStringExtra("Query")
//        Log.d("response activity", "response activity: $responseData")

        // Assuming your data can be parsed into a list of objects
//        val tags = parseData(responseData) // Implement parseData() to convert data

        // Button click handling (unchanged)
        val button = findViewById<Button>(R.id.button3)
        button.setOnClickListener {
            val intent = Intent(this@ResponseActivity, MainActivity::class.java)
            startActivity(intent)
        }

        // Initialize the RecyclerView
        recyclerView = findViewById(R.id.reycyerl_view) // Replace with your RecyclerView ID
        recyclerView.layoutManager = LinearLayoutManager(this)


        // Create and set adapter for RecyclerView
        stringAdapter = StringAdapter(dataList)
        recyclerView.adapter = stringAdapter

    }

    private fun splitByQuotes(query: String?): List<String> {
        if (query == null) {
            return emptyList()
        }

        val splitList = mutableListOf<String>()
        var currentWord = ""
        var inQuotes = false
        for (char in query) {
            if (char == '"') {
                if (inQuotes) {
                    // End of quote
                    splitList.add(currentWord.trim())
                    currentWord = ""
                } else {
                    // Start of quote
                    inQuotes = true
                }
            } else {
                // Regular character
                if (inQuotes) {
                    // Only add the character if it's a letter
                    if (char.isLetter()) {
                        currentWord += char
                    }
                }
            }
        }

        // Add the last word if it's not empty
        if (currentWord.trim().isNotEmpty()) {
            splitList.add(currentWord.trim())
        }

        // Apply the slicing pattern
        val slicedList = splitList.drop(10)

        // Remove elements at odd indices
        val filteredList = slicedList.filterIndexed { index, _ ->
            index % 2 == 0
        }

        // Keep only indices 0, 4, 8, 12, etc.
        val customIndicesList = filteredList.filterIndexed { index, _ ->
            index % 4 == 0
        }

        return customIndicesList
    }








}
