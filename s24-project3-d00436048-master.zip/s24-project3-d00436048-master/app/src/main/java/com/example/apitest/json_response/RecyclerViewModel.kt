package com.example.apitest.json_response

import androidx.lifecycle.ViewModel

class RecyclerViewModel : ViewModel() {

    var json_response = mutableListOf<String>()

    init {
        for (i in 0 until 100) {
            val data = String

            json_response = (json_response + data) as MutableList<String>
        }
    }
}
