package com.example.apitest

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider


class ResponseViewModel : ViewModel() {
    var responseData: String? = null
}